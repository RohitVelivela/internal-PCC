const businessProcesses = [
  { id: 'WF-1001', name: 'Customer Onboarding', domain: 'Sales', stage: 'As-Is Review', status: 'Draft', library: null, owner: 'Sarah Chen', updated: '2 hours ago', desc: 'Capture and verify new customer details, provision accounts, and hand off to the success team.' },
  { id: 'WF-1002', name: 'Invoice Processing', domain: 'Finance', stage: 'To-Be Optimization', status: 'Awaiting Approval', library: null, owner: 'Michael Torres', updated: '5 hours ago', desc: 'Ingest supplier invoices, match against purchase orders, and route exceptions for approval.' },
  { id: 'WF-1003', name: 'Support Ticket Routing', domain: 'Operations', stage: 'Completed', status: 'Approved', library: 'In Library', owner: 'Jennifer Lee', updated: '1 day ago', desc: 'Classify incoming support tickets and route them to the correct queue automatically.' },
  { id: 'WF-1004', name: 'Employee Offboarding', domain: 'HR', stage: 'Discovery', status: 'Draft', library: null, owner: 'David Kumar', updated: '2 days ago', desc: 'Revoke access, reassign work, and complete exit checklist steps when an employee leaves.' },
  { id: 'WF-1005', name: 'Purchase Order Approval', domain: 'Procurement', stage: 'To-Be Optimization', status: 'Awaiting Approval', library: null, owner: 'Emily Zhang', updated: '3 days ago', desc: 'Route purchase orders through the correct approval chain based on spend threshold.' },
  { id: 'WF-1006', name: 'IT Access Provisioning', domain: 'IT', stage: 'Discovery', status: 'Draft', library: null, owner: 'Rachel Kim', updated: '4 days ago', desc: 'Grant and de-provision system access for employees based on role and department.' },
  { id: 'WF-1007', name: 'Vendor Onboarding', domain: 'Procurement', stage: 'As-Is Review', status: 'Draft', library: null, owner: 'Omar Haddad', updated: '5 days ago', desc: 'Collect vendor documentation, run compliance checks, and register approved suppliers.' },
  { id: 'WF-1008', name: 'Data Privacy Compliance', domain: 'Legal', stage: 'To-Be Optimization', status: 'Awaiting Approval', library: null, owner: 'Laura Fischer', updated: '6 days ago', desc: 'Track data subject access requests and ensure responses are completed within SLA.' },
  { id: 'WF-1009', name: 'Claims Handling', domain: 'Operations', stage: 'As-Is Review', status: 'Draft', library: null, owner: 'Daniel Osei', updated: '1 week ago', desc: 'Intake, validate, and route insurance claims for assessment and payout.' },
  { id: 'WF-1010', name: 'Marketing Campaign Process', domain: 'Marketing', stage: 'To-Be Optimization', status: 'Awaiting Approval', library: null, owner: 'Grace Kim', updated: '5 days ago', desc: 'Plan, approve, and launch marketing campaigns across channels with brand sign-off.' }
];

let processFilters = { domain: 'All', status: 'All', owner: 'All', library: 'All' };
let processSearch = '';
let selectedProcessId = null;
let highlightProcessId = null;

function applyIncomingProcessParams(params) {
  processFilters = { domain: 'All', status: 'All', owner: 'All', library: 'All' };
  processSearch = '';
  if (params.statusFilter) processFilters.status = params.statusFilter;
  if (params.libraryFilter) processFilters.library = params.libraryFilter;
  if (params.highlightId) {
    selectedProcessId = params.highlightId;
    highlightProcessId = params.highlightId;
    setTimeout(() => { highlightProcessId = null; render(); }, 1600);
  }
}

function distinctProcessValues(field) {
  return ['All', ...Array.from(new Set(businessProcesses.map(p => p[field]))).sort()];
}

function getFilteredProcesses() {
  return businessProcesses.filter(p =>
    (processFilters.domain === 'All' || p.domain === processFilters.domain) &&
    (processFilters.status === 'All' || p.status === processFilters.status) &&
    (processFilters.owner === 'All' || p.owner === processFilters.owner) &&
    (processFilters.library === 'All' || (processFilters.library === 'In Library' ? p.library === 'In Library' : !p.library)) &&
    (processSearch.trim() === '' || (p.name + ' ' + p.id).toLowerCase().includes(processSearch.trim().toLowerCase()))
  );
}

function ProcessFilterSelect(labelText, key, options) {
  return h('select', {
    class: 'inline-select',
    onchange: (e) => { processFilters[key] = e.target.value; render(); }
  }, options.map(o => h('option', { value: o, selected: processFilters[key] === o ? 'true' : null }, o)));
}

function statusPillClass(status) {
  if (status === 'Draft') return 'pill-gray';
  if (status === 'Awaiting Approval') return 'pill-yellow';
  return 'pill-green';
}

function ProcessDetailDrawer() {
  const p = businessProcesses.find(x => x.id === selectedProcessId);
  if (!p) return null;
  return h('aside', { class: 'side-drawer' }, [
    h('div', { class: 'drawer-head' }, [h('h3', {}, 'Process Details'), h('button', { class: 'icon-button', onclick: () => { selectedProcessId = null; render(); } }, '×')]),
    h('div', { class: 'meta' }, p.id), h('h2', {}, p.name),
    h('div', { class: 'meta' }, p.domain + '  |  ' + p.stage),
    h('div', { style: 'margin:10px 0' }, [h('span', { class: 'pill ' + statusPillClass(p.status) }, p.status), p.library ? h('span', { class: 'pill pill-blue-outline', style: 'margin-left:6px;' }, p.library) : null]),
    h('p', {}, p.desc),
    h('div', { class: 'meta' }, 'Owner: ' + p.owner + '  ·  Updated ' + p.updated),
    h('button', { class: 'detail-button primary', onclick: () => goTo('intake') }, 'Start Related Demand  →')
  ]);
}

function ProcessesMain() {
  if (screenParams && Object.keys(screenParams).length) { applyIncomingProcessParams(screenParams); screenParams = {}; }
  const filtered = getFilteredProcesses();
  return h('main', { class: 'main' }, h('div', { class: 'processes-screen' }, [
    h('div', { class: 'processes-body' }, [
      h('div', { class: 'search-full' }, [h('span', {}, '🔍'), h('input', { placeholder: 'Search processes by name or ID...', value: processSearch, oninput: (e) => { processSearch = e.target.value; render(); } })]),
      h('div', { class: 'filters-row' }, [
        h('span', { class: 'filters-label' }, 'Filters:'),
        ProcessFilterSelect('Domain', 'domain', distinctProcessValues('domain')),
        ProcessFilterSelect('Status', 'status', ['All', 'Draft', 'Awaiting Approval', 'Approved']),
        ProcessFilterSelect('Owner', 'owner', distinctProcessValues('owner')),
        ProcessFilterSelect('Library', 'library', ['All', 'In Library'])
      ]),
      h('p', { class: 'result-count' }, ['Showing ', h('b', {}, String(filtered.length)), ' processes']),
      h('div', { class: 'data-card' }, h('table', {}, [
        h('thead', {}, h('tr', {}, ['Process Name', 'Domain', 'Current Stage', 'Status', 'Library', 'Last Updated', 'Owner', ''].map(x => h('th', {}, x)))),
        h('tbody', {}, filtered.map(p => h('tr', {
          class: (selectedProcessId === p.id ? 'active ' : '') + (highlightProcessId === p.id ? 'flash' : ''),
          onclick: () => { selectedProcessId = p.id; render(); }
        }, [
          h('td', {}, [h('div', { class: 'cell-title' }, p.name), h('div', { class: 'cell-sub' }, p.id)]),
          h('td', {}, h('span', { class: 'pill pill-gray' }, p.domain)),
          h('td', {}, p.stage),
          h('td', {}, h('span', { class: 'pill ' + statusPillClass(p.status) }, p.status)),
          h('td', {}, p.library ? h('span', { class: 'pill pill-blue-outline' }, p.library) : '—'),
          h('td', {}, p.updated), h('td', {}, p.owner), h('td', { class: 'kebab' }, '⋮')
        ])))
      ]))
    ]),
    ProcessDetailDrawer()
  ]));
}
