const DOMAIN_META = {
  'Legal': { areas: ['Generative AI','Document Intelligence','NLP','Workflow Automation'], benefit: 'reduces manual review time and standardizes clause extraction across legal documents' },
  'Finance': { areas: ['Process Automation','RPA','Predictive Analytics','Workflow Automation'], benefit: 'reduces manual processing time and improves financial control accuracy' },
  'HR': { areas: ['Conversational AI','People Analytics','Workflow Automation'], benefit: 'streamlines employee-facing processes and frees up HR capacity for strategic work' },
  'Operations': { areas: ['Process Mining','RPA','Predictive Maintenance'], benefit: 'eliminates manual handoffs and surfaces process bottlenecks in real time' },
  'Customer Experience': { areas: ['Conversational AI','Sentiment Analysis','Personalization'], benefit: 'improves response times and consistency across customer touchpoints' },
  'Supply Chain': { areas: ['Demand Forecasting','Predictive Analytics','IoT'], benefit: 'improves forecast accuracy and end-to-end supply chain visibility' },
  'Technology': { areas: ['Cloud Modernization','DevOps Automation','Observability'], benefit: 'reduces technical debt and improves platform reliability' }
};

const ROLE_ROWS = [
  ['Solution Architect','Azure AI, Solution Design','1','Discovery'],
  ['Data Engineer','Azure, Data Pipelines','1-2','Build'],
  ['ML Engineer','NLP, LLM, Prompt Eng.','1-2','Build'],
  ['Software Developer','.NET, React, APIs','2-3','Build'],
  ['UX / UI Designer','Workflow UX','1','Build'],
  ['QA Engineer','Test Automation','1','Build']
];

const demands = [
  ['DM-10045','Legal','Europe','United Kingdom','NHS Digital','AI Contract Review Assistant',420000,91,true,'Under Review'],
  ['DM-10032','Legal','Europe','United Kingdom','NHS Digital','Legal Clause Extraction',310000,88,true,'Submitted'],
  ['DM-10028','Legal','Europe','United Kingdom','NHS Digital','Contract Risk Scoring',260000,76,false,'Submitted'],
  ['DM-10021','Legal','Europe','United Kingdom','NHS Digital','Legal Knowledge Search',180000,72,true,'More Info Needed'],
  ['DM-10018','Legal','Europe','United Kingdom','NHS Digital','Policy Comparison Tool',95000,61,false,'Draft'],
  ['DM-10050','Finance','Europe','United Kingdom','Meridian Retail Group','Invoice Processing Automation',250000,78,true,'Submitted'],
  ['DM-10051','Finance','Europe','Germany','Deutsche Industriebank','AP Reconciliation Bot',310000,86,true,'Under Review'],
  ['DM-10062','Finance','Europe','France','Aurora Assurance','Expense Audit Assistant',110000,63,false,'Submitted'],
  ['DM-10068','Finance','Asia Pacific','Asia Pacific','Pacific Rim Bank','Fraud Detection Model',340000,89,true,'Under Review'],
  ['DM-10052','HR','Europe','United Kingdom','Falcon Insurance','Employee Onboarding Assistant',150000,70,true,'Draft'],
  ['DM-10053','HR','Americas','Americas','Atlas Manufacturing','People Analytics Dashboard',90000,58,false,'Submitted'],
  ['DM-10063','HR','Asia Pacific','Asia Pacific','Horizon Energy','Recruitment Screening AI',170000,76,true,'Submitted'],
  ['DM-10064','Operations','Europe','United Kingdom','Continental Foods','Ticket Routing Optimization',290000,87,true,'Approved'],
  ['DM-10054','Operations','Asia Pacific','Asia Pacific','Vega Telecom','Warehouse Process Mining',380000,88,true,'Submitted'],
  ['DM-10055','Operations','Americas','Americas','BrightPath Health','Predictive Maintenance Pilot',220000,74,false,'More Info Needed'],
  ['DM-10056','Customer Experience','Europe','United Kingdom','Nordic Retail Group','Support Chatbot Expansion',400000,90,true,'Under Review'],
  ['DM-10057','Customer Experience','Europe','France','Aurora Assurance','Sentiment Analytics Platform',140000,68,false,'Draft'],
  ['DM-10065','Customer Experience','Europe','Germany','Deutsche Industriebank','Personalized Offers Engine',95000,59,false,'Draft'],
  ['DM-10058','Supply Chain','Europe','Germany','Deutsche Industriebank','Demand Forecasting Engine',360000,85,true,'Submitted'],
  ['DM-10059','Supply Chain','Asia Pacific','Asia Pacific','Pacific Rim Bank','Supplier Risk Monitoring',200000,72,true,'Submitted'],
  ['DM-10066','Supply Chain','Europe','United Kingdom','Continental Foods','Inventory Optimization AI',210000,77,true,'Submitted'],
  ['DM-10060','Technology','Europe','United Kingdom','Meridian Retail Group','Legacy App Modernization',500000,60,false,'Draft'],
  ['DM-10061','Technology','Americas','Americas','Atlas Manufacturing','DevOps Pipeline Automation',330000,92,true,'Under Review'],
  ['DM-10067','Technology','Europe','Germany','Deutsche Industriebank','Cloud Cost Optimization',180000,71,true,'Submitted']
].map(r => ({
  id: r[0], domain: r[1], region: r[2], country: r[3], customerAccount: r[4], title: r[5],
  estValue: r[6], priorityScore: r[7], quickWin: r[8], status: r[9],
  priorityLabel: r[7] >= 85 ? 'High' : (r[7] >= 65 ? 'Medium' : 'Low')
}));

const HERO_DETAIL = {
  executiveSummary: 'Implement an AI-powered contract review solution to reduce manual review time, improve accuracy, and standardize clause extraction across legal documents.',
  approach: 'Start with a focused MVP to ingest contracts, extract key clauses, and provide AI-assisted review with a human-in-the-loop workflow. Expand to full contract lifecycle management based on pilot outcomes.',
  submittedBy: 'Sarah Thompson', submittedOn: '12 Jun 2024', accountOwner: 'James Walker', tags: 'AI, Contracts, Automation'
};

function deriveDetail(d) {
  if (d.id === 'DM-10045') {
    const meta = DOMAIN_META[d.domain];
    return Object.assign({
      strategicImpact: 'High', businessValue: 'High', roi: '2.8x', ease: 'Medium', confidence: 'High', strategicFit: 'High',
      areas: meta.areas
    }, HERO_DETAIL);
  }
  const seed = seedFromId(d.id);
  const meta = DOMAIN_META[d.domain];
  const level = d.priorityScore >= 85 ? 'High' : (d.priorityScore >= 65 ? 'Medium' : 'Low');
  const ease = ['Low', 'Medium', 'High'][seed % 3];
  const roi = (1.4 + (seed % 26) / 10).toFixed(1) + 'x';
  return {
    strategicImpact: level, businessValue: level, roi: roi, ease: ease,
    confidence: d.priorityScore >= 85 ? 'High' : (d.priorityScore >= 70 ? 'Medium' : 'Low'),
    strategicFit: level,
    areas: meta.areas,
    executiveSummary: 'Address the "' + d.title + '" need for ' + d.customerAccount + ' by delivering a ' + meta.areas[0].toLowerCase() + '-led solution that ' + meta.benefit + '.',
    approach: 'Start with a focused MVP for ' + d.title.toLowerCase() + ', validate with a pilot group, then expand based on outcomes.',
    submittedBy: pick(NAME_POOL, seed), submittedOn: '0' + (1 + seed % 9) + ' Jun 2024',
    accountOwner: pick(NAME_POOL, seed + 7), tags: meta.areas.slice(0, 3).join(', ')
  };
}

let expandedRegions = { 'Europe': true, 'Asia Pacific': false, 'Americas': false };
const emptyFilters = () => ({ region: 'All', country: 'All', domain: 'All', priority: 'All', quickWin: 'All', account: 'All' });
let appliedFilters = Object.assign(emptyFilters(), { domain: 'Legal', region: 'Europe', country: 'United Kingdom' });
let pendingFilters = Object.assign({}, appliedFilters);
let selectedDemandId = 'DM-10045';
let currentPage = 1;
let searchTerm = '';
let searchFocused = false;
const PAGE_SIZE = 5;

function distinctValues(field) {
  const s = new Set(demands.map(d => d[field]));
  return ['All', ...Array.from(s).sort()];
}

function HeatFilterPanel() {
  function selectField(labelText, key, options) {
    return h('div', { class: 'field' }, [
      h('label', {}, labelText),
      h('select', {
        onchange: (e) => { pendingFilters[key] = e.target.value; }
      }, options.map(o => h('option', { value: o, selected: pendingFilters[key] === o ? 'true' : null }, o)))
    ]);
  }
  return h('aside', { class: 'filter-panel' }, [
    h('div', { class: 'filter-head' }, [h('h3', {}, 'Filters'), h('button', { class: 'clear', onclick: () => { pendingFilters = emptyFilters(); appliedFilters = emptyFilters(); currentPage = 1; searchTerm = ''; render(); } }, 'Clear All')]),
    h('div', { class: 'field' }, [h('label', {}, 'Date Range'), h('input', { value: '01 Apr 2024 - 30 Jun 2024', readonly: 'true' })]),
    h('div', { class: 'filter-group' }, [h('h4', {}, 'Customer'), selectField('Customer Account', 'account', distinctValues('customerAccount'))]),
    h('div', { class: 'filter-group' }, [h('h4', {}, 'Geography'), selectField('Region', 'region', distinctValues('region')), selectField('Country', 'country', distinctValues('country'))]),
    h('div', { class: 'filter-group' }, [h('h4', {}, 'Domain / Solution'), selectField('Domain', 'domain', distinctValues('domain'))]),
    h('div', { class: 'filter-group' }, [h('h4', {}, 'Opportunity'), selectField('Priority', 'priority', ['All', 'High', 'Medium', 'Low']), selectField('Quick Win', 'quickWin', ['All', 'Yes', 'No'])]),
    h('button', { class: 'apply', onclick: () => { appliedFilters = Object.assign({}, pendingFilters); currentPage = 1; render(); } }, 'Apply Filters'),
    h('button', { class: 'save' }, 'Save View')
  ]);
}

function getFilteredDemands() {
  return demands.filter(d =>
    (appliedFilters.region === 'All' || d.region === appliedFilters.region) &&
    (appliedFilters.country === 'All' || d.country === appliedFilters.country) &&
    (appliedFilters.domain === 'All' || d.domain === appliedFilters.domain) &&
    (appliedFilters.priority === 'All' || d.priorityLabel === appliedFilters.priority) &&
    (appliedFilters.quickWin === 'All' || (appliedFilters.quickWin === 'Yes' ? d.quickWin : !d.quickWin)) &&
    (appliedFilters.account === 'All' || d.customerAccount === appliedFilters.account) &&
    (searchTerm.trim() === '' || (d.title + ' ' + d.customerAccount + ' ' + d.id).toLowerCase().includes(searchTerm.trim().toLowerCase()))
  );
}

function HeatKpis() {
  const k = [['Total Demands', '387', '18% vs prior period'], ['Est. Annual Value', '£98.7M', '22% vs prior period'], ['Avg. Priority Score', '74', '5 vs prior period'], ['High Priority Demands', '142 (37%)', '12% vs prior period'], ['Quick Wins', '96 (25%)', '8% vs prior period'], ['Strategic Bets', '41 (11%)', '4% vs prior period']];
  return h('div', { class: 'kpis' }, k.map(x => h('div', { class: 'kpi' }, [h('small', {}, x[0]), h('b', {}, x[1]), h('span', { class: 'up' }, '↑ ' + x[2])])));
}

function selectCell(domain, region, country) {
  appliedFilters = Object.assign(emptyFilters(), { domain: domain, region: region, country: country || 'All' });
  pendingFilters = Object.assign({}, appliedFilters);
  currentPage = 1;
  searchTerm = '';
  render();
  const target = document.getElementById('demand-results');
  if (target && typeof target.scrollIntoView === 'function') target.scrollIntoView({ block: 'nearest' });
}

function HeatmapTable() {
  const europe = { finance: 28, hr: 16, ops: 34, legal: 22, cx: 18, sc: 15, tech: 27, total: 160, financeV: '£6.2M', hrV: '£2.1M', opsV: '£7.8M', legalV: '£4.3M', cxV: '£3.2M', scV: '£2.6M', techV: '£5.1M', totalV: '£31.3M' };
  const uk = { finance: 12, hr: 6, ops: 14, legal: 9, cx: 8, sc: 5, tech: 11, total: 65, financeV: '£2.8M', hrV: '£0.9M', opsV: '£3.1M', legalV: '£1.7M', cxV: '£1.2M', scV: '£0.8M', techV: '£2.1M', totalV: '£11.6M' };
  const germany = { finance: 9, hr: 5, ops: 10, legal: 6, cx: 5, sc: 5, tech: 8, total: 48, financeV: '£1.9M', hrV: '£0.7M', opsV: '£2.3M', legalV: '£1.1M', cxV: '£0.9M', scV: '£0.7M', techV: '£1.6M', totalV: '£7.2M' };
  const france = { finance: 7, hr: 5, ops: 10, legal: 7, cx: 5, sc: 5, tech: 8, total: 47, financeV: '£1.5M', hrV: '£0.5M', opsV: '£2.4M', legalV: '£1.5M', cxV: '£1.1M', scV: '£1.1M', techV: '£1.4M', totalV: '£8.0M' };
  const apac = { finance: 22, hr: 14, ops: 26, legal: 18, cx: 16, sc: 14, tech: 20, total: 130, financeV: '£5.0M', hrV: '£1.7M', opsV: '£6.2M', legalV: '£3.0M', cxV: '£2.8M', scV: '£2.4M', techV: '£4.0M', totalV: '£25.1M' };
  const americas = { finance: 20, hr: 12, ops: 24, legal: 16, cx: 14, sc: 12, tech: 19, total: 117, financeV: '£4.8M', hrV: '£1.6M', opsV: '£6.0M', legalV: '£2.8M', cxV: '£2.3M', scV: '£2.1M', techV: '£3.6M', totalV: '£23.2M' };
  const grand = { finance: 70, hr: 42, ops: 84, legal: 56, cx: 48, sc: 41, tech: 66, total: 387, financeV: '£16.0M', hrV: '£5.4M', opsV: '£20.0M', legalV: '£10.1M', cxV: '£8.3M', scV: '£7.1M', techV: '£12.7M', totalV: '£98.7M' };
  const domainKeys = [['finance', 'Finance'], ['hr', 'HR'], ['ops', 'Operations'], ['legal', 'Legal'], ['cx', 'Customer Experience'], ['sc', 'Supply Chain'], ['tech', 'Technology']];
  const headers = ['Region / Country', 'Finance', 'HR', 'Operations', 'Legal', 'Customer Experience', 'Supply Chain', 'Technology', 'Total'];

  function levelClass(count) {
    if (count >= 24) return 'h4'; if (count >= 16) return 'h3'; if (count >= 8) return 'h2'; return 'h1';
  }

  function domainCells(row, region, country) {
    const cells = domainKeys.map(([k, name]) => h('td', {
      class: 'heat-cell ' + levelClass(row[k]), onclick: () => selectCell(name, region, country)
    }, [String(row[k]), h('span', {}, '(' + row[k + 'V'] + ')')]));
    cells.push(h('td', { class: 'heat-cell total', onclick: () => selectCell('All', region, country) }, [String(row.total), h('span', {}, '(' + row.totalV + ')')]));
    return cells;
  }

  const rows = [];
  rows.push(h('tr', {}, [h('td', { class: 'region-row', onclick: () => { expandedRegions['Europe'] = !expandedRegions['Europe']; render(); } }, (expandedRegions['Europe'] ? '⌄  ' : '›  ') + 'Europe'), ...domainCells(europe, 'Europe', 'All')]));
  if (expandedRegions['Europe']) {
    rows.push(h('tr', {}, [h('td', {}, '  United Kingdom'), ...domainCells(uk, 'Europe', 'United Kingdom')]));
    rows.push(h('tr', {}, [h('td', {}, '  Germany'), ...domainCells(germany, 'Europe', 'Germany')]));
    rows.push(h('tr', {}, [h('td', {}, '  France'), ...domainCells(france, 'Europe', 'France')]));
  }
  rows.push(h('tr', {}, [h('td', { class: 'region-row', onclick: () => { expandedRegions['Asia Pacific'] = !expandedRegions['Asia Pacific']; render(); } }, (expandedRegions['Asia Pacific'] ? '⌄  ' : '›  ') + 'Asia Pacific'), ...domainCells(apac, 'Asia Pacific', 'Asia Pacific')]));
  if (expandedRegions['Asia Pacific']) {
    rows.push(h('tr', {}, h('td', { colspan: '9', class: 'hint-row' }, 'Country-level breakdown is not available in this demo dataset.')));
  }
  rows.push(h('tr', {}, [h('td', { class: 'region-row', onclick: () => { expandedRegions['Americas'] = !expandedRegions['Americas']; render(); } }, (expandedRegions['Americas'] ? '⌄  ' : '›  ') + 'Americas'), ...domainCells(americas, 'Americas', 'Americas')]));
  if (expandedRegions['Americas']) {
    rows.push(h('tr', {}, h('td', { colspan: '9', class: 'hint-row' }, 'Country-level breakdown is not available in this demo dataset.')));
  }
  rows.push(h('tr', {}, [h('td', {}, 'Grand Total'), ...domainCells(grand, 'All', 'All')]));

  return h('table', { class: 'heat-table' }, [h('thead', {}, h('tr', {}, headers.map(x => h('th', {}, x)))), h('tbody', {}, rows)]);
}

function contextLabel() {
  const domainPart = appliedFilters.domain === 'All' ? 'All Domains' : appliedFilters.domain;
  const regionPart = appliedFilters.country !== 'All' ? appliedFilters.country : (appliedFilters.region !== 'All' ? appliedFilters.region : 'All Regions');
  const priorityPart = appliedFilters.priority === 'All' ? 'All Priority' : (appliedFilters.priority + ' Priority');
  return domainPart + ' / ' + regionPart + ' / ' + priorityPart;
}

function DemandResults() {
  const filtered = getFilteredDemands();
  if (!filtered.find(d => d.id === selectedDemandId) && filtered.length > 0) selectedDemandId = filtered[0].id;
  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  if (currentPage > totalPages) currentPage = totalPages;
  const startIdx = (currentPage - 1) * PAGE_SIZE;
  const pageRows = filtered.slice(startIdx, startIdx + PAGE_SIZE);
  const estSum = filtered.reduce((a, d) => a + d.estValue, 0);

  return h('div', { class: 'section-card', id: 'demand-results' }, [
    h('div', { class: 'result-head' }, [
      h('div', {}, [h('h2', {}, ['Demands in ', contextLabel(), ' ', h('span', { class: 'blue' }, '(' + filtered.length + ')')]), h('span', { class: 'tag' }, 'Est. Annual Value: ' + fmtMoney(estSum))]),
      h('input', {
        class: 'search', placeholder: 'Search demands...', value: searchTerm,
        oninput: (e) => { searchTerm = e.target.value; currentPage = 1; render(); },
        onfocus: () => { searchFocused = true; }, onblur: () => { searchFocused = false; },
        id: 'demand-search'
      })
    ]),
    filtered.length === 0
      ? h('p', { class: 'hint empty-state' }, 'No matching demo demand records for this segment. Try clearing filters.')
      : h('table', { class: 'demand-table' }, [
        h('thead', {}, h('tr', {}, ['Priority', 'Demand ID', 'Demand Title', 'Customer Account', 'Est. Annual Value', 'Priority Score', 'Quick Win', 'Status'].map(x => h('th', {}, x)))),
        h('tbody', {}, pageRows.map(d => h('tr', { class: selectedDemandId === d.id ? 'active' : '', onclick: () => { selectedDemandId = d.id; render(); } }, [
          h('td', {}, h('span', { class: 'priority ' + d.priorityLabel.toLowerCase() }, d.priorityLabel)),
          h('td', { class: 'blue' }, d.id), h('td', {}, d.title), h('td', {}, d.customerAccount),
          h('td', {}, fmtMoney(d.estValue)), h('td', {}, String(d.priorityScore)),
          h('td', {}, h('span', { class: d.quickWin ? 'green' : 'red' }, d.quickWin ? 'Yes' : 'No')),
          h('td', {}, h('span', { class: 'status' }, d.status))
        ])))
      ]),
    filtered.length > 0 ? h('div', { class: 'pagination' }, [
      h('button', { class: 'page-btn', disabled: currentPage <= 1 ? 'true' : null, onclick: () => { currentPage--; render(); } }, '‹ Prev'),
      h('p', { class: 'hint' }, 'Showing ' + (startIdx + 1) + ' to ' + Math.min(startIdx + PAGE_SIZE, filtered.length) + ' of ' + filtered.length + ' demands'),
      h('button', { class: 'page-btn', disabled: currentPage >= totalPages ? 'true' : null, onclick: () => { currentPage++; render(); } }, 'Next ›')
    ]) : null
  ]);
}

function DemandDetail() {
  const d = demands.find(x => x.id === selectedDemandId);
  if (!d) return h('aside', { class: 'detail' }, h('p', { class: 'hint' }, 'No demand selected.'));
  const det = deriveDetail(d);
  return h('aside', { class: 'detail' }, [
    h('div', { class: 'detail-top' }, [h('h3', {}, 'Demand Details'), h('button', { class: 'icon-button' }, '×')]),
    h('div', { class: 'meta' }, d.id + '   '), h('span', { class: 'priority ' + d.priorityLabel.toLowerCase() }, d.priorityLabel + ' Priority'),
    h('h2', {}, d.title),
    h('div', { class: 'meta' }, d.customerAccount + '  |  ' + d.domain + '  |  ' + d.country),
    h('div', { style: 'margin:10px 0' }, [h('span', { class: 'status' }, d.status), document.createTextNode('  '), h('span', { class: 'status' }, d.quickWin ? 'Quick Win' : 'Strategic Bet')]),
    h('div', { class: 'detail-kpis' }, [
      ['Priority Score', d.priorityScore + ' /100', 'blue'], ['Strategic Impact', det.strategicImpact, det.strategicImpact === 'High' ? 'green' : det.strategicImpact === 'Medium' ? 'orange' : 'red'],
      ['Business Value', det.businessValue, det.businessValue === 'High' ? 'green' : det.businessValue === 'Medium' ? 'orange' : 'red'],
      ['Est. Annual Value', fmtMoney(d.estValue), ''], ['ROI Potential', det.roi, ''],
      ['Ease of Implementation', det.ease, det.ease === 'High' ? 'green' : det.ease === 'Medium' ? 'orange' : 'red'],
      ['Quick Win Potential', d.quickWin ? 'Yes' : 'No', d.quickWin ? 'green' : 'red'],
      ['Confidence Level', det.confidence, det.confidence === 'High' ? 'green' : det.confidence === 'Medium' ? 'orange' : 'red'],
      ['Strategic Fit', det.strategicFit, det.strategicFit === 'High' ? 'green' : det.strategicFit === 'Medium' ? 'orange' : 'red']
    ].map(x => h('div', { class: 'mini' }, [h('small', {}, x[0]), h('b', { class: x[2] }, x[1])]))),
    h('h4', {}, 'Executive Summary'), h('p', {}, det.executiveSummary),
    h('h4', {}, 'Solution Areas'), h('p', {}, det.areas.join(' · ')),
    h('h4', {}, 'Recommended Solution Approach (High Level)'), h('p', {}, det.approach),
    h('h4', {}, 'Recommended Skills / Resource Roles (Advisory)'),
    h('table', { class: 'role-table' }, [h('thead', {}, h('tr', {}, ['Role', 'Key Skills', 'FTE', 'Phase'].map(x => h('th', {}, x)))), h('tbody', {}, ROLE_ROWS.map(r => h('tr', {}, r.map(c => h('td', {}, c)))))]),
    h('h4', {}, 'Additional Information'), h('p', {}, 'Submitted by ' + det.submittedBy + ' · Submitted on ' + det.submittedOn + ' · Account Owner ' + det.accountOwner + ' · Tags: ' + det.tags),
    h('button', { class: 'detail-button' }, 'View Full Demand Record  ↗')
  ]);
}

function HeatmapMain() {
  return h('main', { class: 'main' }, h('div', { class: 'heatmap-screen' }, [
    HeatFilterPanel(),
    h('div', { class: 'heat-main' }, [
      HeatKpis(),
      h('div', { class: 'section-card' }, [
        h('div', { class: 'section-title' }, [h('h2', {}, 'Portfolio Heatmap (Count of Demands)'), h('div', { class: 'controls' }, [h('span', {}, 'View by:'), h('select', {}, h('option', {}, 'Domain')), h('span', {}, 'Color by:'), h('select', {}, h('option', {}, 'Avg. Priority Score')), h('span', { class: 'legend' }, ['Low ', h('span', { class: 'grad' }), ' High']), h('label', {}, [h('input', { type: 'checkbox', checked: 'true' }), ' Show values'])])]),
        HeatmapTable(),
        h('p', { class: 'hint' }, 'Click on any cell to view demands. Drill down by region, country, domain, or account using filters.')
      ]),
      DemandResults()
    ]),
    DemandDetail()
  ]));
}
