const draftsData = [
  { id: 'DF-2001', name: 'Customer Onboarding', domain: 'Sales', stage: 'As-Is Review', owner: 'Sarah Chen', updated: '2 hours ago', desc: 'Draft assessment capturing the current customer onboarding workflow before optimization.' },
  { id: 'DF-2002', name: 'Expense Approval', domain: 'Finance', stage: 'Draft', owner: 'Michael Torres', updated: '5 hours ago', desc: 'Early draft covering expense submission, manager approval, and reimbursement steps.' },
  { id: 'DF-2003', name: 'IT Asset Provisioning', domain: 'IT', stage: 'Discovery', owner: 'Rachel Kim', updated: '1 day ago', desc: 'Discovery notes on hardware and software provisioning for new starters. Compliance requested additional security checkpoints.' },
  { id: 'DF-2004', name: 'Employee Onboarding', domain: 'HR', stage: 'Draft', owner: 'David Kumar', updated: '2 days ago', desc: 'Draft covering new-hire paperwork, equipment requests, and first-week scheduling.' },
  { id: 'DF-2005', name: 'Vendor Risk Assessment', domain: 'Procurement', stage: 'Discovery', owner: 'Omar Haddad', updated: '3 days ago', desc: 'Initial notes on scoring vendor risk before contract sign-off.' },
  { id: 'DF-2006', name: 'Data Privacy Compliance', domain: 'Legal', stage: 'As-Is Review', owner: 'Laura Fischer', updated: '4 days ago', desc: 'Draft mapping of current data subject access request handling.' }
];

let draftSearch = '';
let selectedDraftId = null;
let highlightDraftId = null;

function applyIncomingDraftParams(params) {
  draftSearch = '';
  if (params.highlightId) {
    selectedDraftId = params.highlightId;
    highlightDraftId = params.highlightId;
    setTimeout(() => { highlightDraftId = null; render(); }, 1600);
  }
}

function getFilteredDrafts() {
  return draftsData.filter(d => draftSearch.trim() === '' || (d.name + ' ' + d.id).toLowerCase().includes(draftSearch.trim().toLowerCase()));
}

function DraftDetailDrawer() {
  const d = draftsData.find(x => x.id === selectedDraftId);
  if (!d) return null;
  return h('aside', { class: 'side-drawer' }, [
    h('div', { class: 'drawer-head' }, [h('h3', {}, 'Draft Details'), h('button', { class: 'icon-button', onclick: () => { selectedDraftId = null; render(); } }, '×')]),
    h('div', { class: 'meta' }, d.id), h('h2', {}, d.name),
    h('div', { class: 'meta' }, d.domain + '  |  ' + d.stage),
    h('p', {}, d.desc),
    h('div', { class: 'meta' }, 'Owner: ' + d.owner + '  ·  Updated ' + d.updated),
    h('button', { class: 'detail-button primary', onclick: () => goTo('intake') }, 'Resume in Demand Intake Agent  →')
  ]);
}

function DraftsMain() {
  if (screenParams && Object.keys(screenParams).length) { applyIncomingDraftParams(screenParams); screenParams = {}; }
  const filtered = getFilteredDrafts();
  return h('main', { class: 'main' }, h('div', { class: 'processes-screen' }, [
    h('div', { class: 'processes-body' }, [
      h('div', { class: 'search-full' }, [h('span', {}, '🔍'), h('input', { placeholder: 'Search drafts by name or ID...', value: draftSearch, oninput: (e) => { draftSearch = e.target.value; render(); } })]),
      h('p', { class: 'result-count' }, ['Showing ', h('b', {}, String(filtered.length)), ' drafts']),
      h('div', { class: 'data-card' }, h('table', {}, [
        h('thead', {}, h('tr', {}, ['Draft Name', 'Domain', 'Stage', 'Owner', 'Updated', ''].map(x => h('th', {}, x)))),
        h('tbody', {}, filtered.map(d => h('tr', {
          class: (selectedDraftId === d.id ? 'active ' : '') + (highlightDraftId === d.id ? 'flash' : ''),
          onclick: () => { selectedDraftId = d.id; render(); }
        }, [
          h('td', {}, [h('div', { class: 'cell-title' }, d.name), h('div', { class: 'cell-sub' }, d.id)]),
          h('td', {}, h('span', { class: 'pill pill-gray' }, d.domain)),
          h('td', {}, d.stage), h('td', {}, d.owner), h('td', {}, d.updated), h('td', { class: 'kebab' }, '⋮')
        ])))
      ]))
    ]),
    DraftDetailDrawer()
  ]));
}
