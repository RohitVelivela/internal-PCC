function CurrentScreenMain() {
  if (screen === 'home') return HomeMain();
  if (screen === 'processes') return ProcessesMain();
  if (screen === 'drafts') return DraftsMain();
  if (screen === 'intake') return [IntakeSidebar(), IntakeMain()];
  if (screen === 'heatmap') return HeatmapMain();
  return HomeMain();
}

function render() {
  root.innerHTML = '';

  if (screen === 'login') {
    root.appendChild(LoginMain());
    return;
  }

  const content = CurrentScreenMain();
  const workspaceChildren = Array.isArray(content) ? content : [content];
  const app = h('div', { class: 'app' }, [TopBar(), h('div', { class: 'workspace' }, workspaceChildren)]);
  root.appendChild(app);

  if (screen === 'intake') {
    const msgArea = root.querySelector('.messages');
    if (msgArea) msgArea.scrollTop = msgArea.scrollHeight;
  }
  if (screen === 'heatmap' && searchFocused) {
    const s = document.getElementById('demand-search');
    if (s) { s.focus(); const v = s.value; s.setSelectionRange(v.length, v.length); }
  }
}

render();
