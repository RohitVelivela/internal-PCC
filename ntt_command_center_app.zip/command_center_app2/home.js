const HOME_STATS = [
  { icon: '🕐', num: '7', label: 'Open Approvals', bg: 'bg-yellow', target: { screen: 'processes', params: { statusFilter: 'Awaiting Approval' } } },
  { icon: '📄', num: '12', label: 'Draft Processes', bg: 'bg-blue', target: { screen: 'processes', params: { statusFilter: 'Draft' } } },
  { icon: 'ⓘ', num: '5', label: 'Awaiting Review', bg: 'bg-purple', target: { screen: 'drafts', params: {} } },
  { icon: '✓', num: '18', label: 'Approved', bg: 'bg-green', target: { screen: 'processes', params: { statusFilter: 'Approved' } } },
  { icon: '🗄', num: '156', label: 'Added to Library', bg: 'bg-teal', target: { screen: 'processes', params: { libraryFilter: 'In Library' } } }
];

const NEEDS_ATTENTION = [
  { tag: 'Missing Information', tagClass: 'tag-red', title: 'Customer Onboarding', time: '3h ago', desc: 'Missing integration details for Salesforce connector', action: 'Update Details', target: { screen: 'processes', params: { highlightId: 'WF-1001' } } },
  { tag: 'Confidence Gap', tagClass: 'tag-yellow', title: 'Invoice Processing', time: '5h ago', desc: 'Unable to map approval routing for Finance team escalation path', action: 'Review Extraction', target: { screen: 'processes', params: { highlightId: 'WF-1002' } } },
  { tag: 'Returned for Changes', tagClass: 'tag-red', title: 'IT Asset Provisioning', time: '1d ago', desc: 'Compliance team requested additional security checkpoints', action: 'Review Comments', target: { screen: 'drafts', params: { highlightId: 'DF-2003' } } },
  { tag: 'Overdue Approval', tagClass: 'tag-red', title: 'Marketing Campaign Process', time: '5d ago', desc: 'Pending approval from Marketing Director for 5 days', action: 'Review Approval', target: { screen: 'processes', params: { highlightId: 'WF-1010' } } }
];

function HomeStatCard(s) {
  return h('div', { class: 'stat-card', onclick: () => goTo(s.target.screen, s.target.params) }, [
    h('div', { class: 'stat-icon ' + s.bg }, s.icon),
    h('div', { class: 'stat-num' }, s.num),
    h('div', { class: 'stat-label' }, s.label)
  ]);
}

function NeedsAttentionRow(item) {
  return h('div', { class: 'attn-item' }, [
    h('div', { class: 'attn-left' }, [
      h('div', {}, h('span', { class: 'tag-pill ' + item.tagClass }, item.tag)),
      h('span', { class: 'attn-title' }, item.title), h('span', { class: 'attn-time' }, item.time),
      h('div', { class: 'attn-desc' }, item.desc)
    ]),
    h('button', { class: 'ghost-btn', onclick: () => goTo(item.target.screen, item.target.params) }, item.action)
  ]);
}

function HomeMain() {
  return h('main', { class: 'main' }, h('div', { class: 'home-screen' }, [
    h('div', { class: 'stat-row' }, HOME_STATS.map(HomeStatCard)),
    h('div', { class: 'panel attn-panel' }, [
      h('div', { class: 'panel-head' }, [
        h('span', { class: 'warn-icon' }, '⚠'),
        h('h2', {}, 'Needs Attention'),
        h('span', { class: 'badge-red' }, NEEDS_ATTENTION.length + ' items')
      ]),
      ...NEEDS_ATTENTION.map(NeedsAttentionRow)
    ])
  ]));
}
