const h = (tag, attrs = {}, children = []) => {
  const el = document.createElement(tag);
  Object.entries(attrs || {}).forEach(([k, v]) => {
    if (v === null || v === undefined) return;
    if (k === 'class') el.className = v;
    else if (k === 'html') el.innerHTML = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else el.setAttribute(k, v);
  });
  (Array.isArray(children) ? children : [children]).forEach(c => {
    if (c === null || c === undefined) return;
    el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  });
  return el;
};

const root = document.getElementById('root');

const PERSONAS = [
  { key: 'requestor', title: 'Demand Requestor', desc: 'Submit a business need and track it through intake and review.', icon: '🧑‍💼', name: 'Jordan Blake', role: 'Demand Requestor', defaultScreen: 'intake', navKeys: ['home', 'drafts', 'intake'] },
  { key: 'lead', title: 'NTT Data Solution Lead', desc: 'Review, prioritize, and manage the demand portfolio end to end.', icon: '🧭', name: 'Alex Morgan', role: 'Portfolio Manager', defaultScreen: 'home', navKeys: ['home', 'processes', 'drafts', 'intake', 'heatmap'] }
];

const NAV_ITEMS = [
  { key: 'home', label: 'Home' },
  { key: 'processes', label: 'Business Processes' },
  { key: 'drafts', label: 'Drafts' },
  { key: 'intake', label: 'Demand Intake Agent' },
  { key: 'heatmap', label: 'Demand Priority Heatmap' }
];

let screen = 'login';
let screenParams = {};
let currentPersona = null;

function goTo(name, params) {
  screen = name;
  screenParams = params || {};
  render();
}

function currentPersonaInfo() {
  return PERSONAS.find(p => p.key === currentPersona) || null;
}

function visibleNavItems() {
  const info = currentPersonaInfo();
  if (!info) return NAV_ITEMS;
  return NAV_ITEMS.filter(item => info.navKeys.includes(item.key));
}

function logOut() {
  currentPersona = null;
  screen = 'login';
  screenParams = {};
  render();
}

function seedFromId(id) { let s = 0; for (let i = 0; i < id.length; i++) s = (s * 31 + id.charCodeAt(i)) >>> 0; return s; }
function pick(arr, seed) { return arr[seed % arr.length]; }
function fmtMoney(n) {
  if (n >= 1000000) return '£' + (n / 1000000).toFixed(1) + 'M';
  return '£' + n.toLocaleString();
}

const NAME_POOL = ['Sarah Thompson','James Walker','Priya Patel','Michael Chen','Laura Fischer','Daniel Osei','Elena Rossi','Tom Becker','Grace Kim','Omar Haddad','Nadia Kranz','Liam OConnor'];

function TopBar() {
  const info = currentPersonaInfo();
  const displayName = info ? info.name : 'Alex Morgan';
  const displayRole = info ? info.role : 'Portfolio Manager';
  const initials = displayName.split(' ').map(w => w[0]).join('');
  return h('div', { class: 'topbar' }, [
    h('div', { style: 'display:flex;align-items:center;height:100%;' }, [
      h('div', { class: 'brand' }, [h('span', { class: 'logo-ring' }), h('span', {}, 'NTT DATA')]),
      h('span', { class: 'divider' }),
      h('span', { class: 'product' }, 'Command Center'),
      h('div', { class: 'topnav' }, visibleNavItems().map(item =>
        h('button', { class: screen === item.key ? 'active' : '', onclick: () => goTo(item.key) }, item.label)
      ))
    ]),
    h('div', { class: 'top-actions' }, [
      h('button', { class: 'icon-button' }, '?'),
      h('button', { class: 'icon-button' }, [document.createTextNode('🔔'), h('span', { class: 'badge-dot' }, '3')]),
      h('div', { class: 'profile' }, [h('span', { class: 'avatar' }, initials), h('div', {}, [h('b', {}, displayName), h('small', {}, displayRole)]), h('span', {}, '⌄')]),
      h('button', { class: 'icon-button logout-btn', onclick: logOut, title: 'Log out' }, '⏻')
    ])
  ]);
}
