const LOGIN_BG_SVG = `
<svg class="login-bg-svg" viewBox="0 0 600 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="loginGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#04213d"/>
      <stop offset="55%" stop-color="#0a4a8f"/>
      <stop offset="100%" stop-color="#0f6fc5"/>
    </linearGradient>
    <radialGradient id="glow1" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#ff3b52" stop-opacity="0.35"/>
      <stop offset="100%" stop-color="#ff3b52" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect x="0" y="0" width="600" height="900" fill="url(#loginGrad)"/>
  <circle cx="492" cy="126" r="220" fill="url(#glow1)"/>
  <line x1="89" y1="212" x2="53" y2="197" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="378" y1="340" x2="428" y2="268" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="52" y1="456" x2="41" y2="393" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="121" y1="520" x2="196" y2="524" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="121" y1="520" x2="157" y2="514" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="371" y1="835" x2="465" y2="621" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="343" y1="361" x2="274" y2="278" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="567" y1="60" x2="569" y2="122" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="193" y1="722" x2="314" y2="773" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="320" y1="334" x2="274" y2="278" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="258" y1="731" x2="371" y2="835" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="258" y1="731" x2="314" y2="773" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="41" y1="393" x2="121" y2="520" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="59" y1="98" x2="101" y2="121" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="201" y1="150" x2="89" y2="212" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="201" y1="150" x2="327" y2="74" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="371" y1="835" x2="314" y2="773" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="258" y1="731" x2="193" y2="722" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="501" y1="269" x2="569" y2="122" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="89" y1="212" x2="101" y2="121" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="501" y1="269" x2="428" y2="268" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="465" y1="621" x2="314" y2="773" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="101" y1="121" x2="53" y2="197" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="52" y1="456" x2="121" y2="520" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="59" y1="98" x2="53" y2="197" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="343" y1="361" x2="378" y2="340" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="201" y1="150" x2="101" y2="121" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="320" y1="334" x2="343" y2="361" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="343" y1="361" x2="401" y2="388" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="501" y1="269" x2="378" y2="340" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="196" y1="524" x2="157" y2="514" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="385" y1="82" x2="567" y2="60" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="385" y1="82" x2="327" y2="74" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="320" y1="334" x2="378" y2="340" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/><line x1="378" y1="340" x2="401" y2="388" stroke="#ffffff" stroke-opacity="0.14" stroke-width="1"/>
  <circle cx="201" cy="150" r="3.8" fill="#ffffff" fill-opacity="0.73"/><circle cx="385" cy="82" r="4.0" fill="#ffffff" fill-opacity="0.37"/><circle cx="320" cy="334" r="4.8" fill="#ffffff" fill-opacity="0.64"/><circle cx="52" cy="456" r="3.4" fill="#ffffff" fill-opacity="0.70"/><circle cx="41" cy="393" r="4.2" fill="#ffffff" fill-opacity="0.58"/><circle cx="59" cy="98" r="5.3" fill="#ffffff" fill-opacity="0.59"/><circle cx="258" cy="731" r="2.7" fill="#ffffff" fill-opacity="0.70"/><circle cx="89" cy="212" r="5.5" fill="#ffffff" fill-opacity="0.76"/><circle cx="371" cy="835" r="3.7" fill="#ff3b52" fill-opacity="0.90"/><circle cx="343" cy="361" r="3.9" fill="#ff3b52" fill-opacity="0.90"/><circle cx="567" cy="60" r="2.7" fill="#ff3b52" fill-opacity="0.90"/><circle cx="501" cy="269" r="3.2" fill="#ffffff" fill-opacity="0.55"/><circle cx="101" cy="121" r="2.7" fill="#ffffff" fill-opacity="0.57"/><circle cx="193" cy="722" r="5.2" fill="#ffffff" fill-opacity="0.76"/><circle cx="121" cy="520" r="3.3" fill="#ffffff" fill-opacity="0.56"/><circle cx="378" cy="340" r="5.2" fill="#ffffff" fill-opacity="0.83"/><circle cx="327" cy="74" r="3.0" fill="#ffffff" fill-opacity="0.47"/><circle cx="53" cy="197" r="4.0" fill="#ffffff" fill-opacity="0.64"/><circle cx="401" cy="388" r="2.5" fill="#ffffff" fill-opacity="0.56"/><circle cx="196" cy="524" r="4.2" fill="#ffffff" fill-opacity="0.83"/><circle cx="274" cy="278" r="4.0" fill="#ffffff" fill-opacity="0.66"/><circle cx="465" cy="621" r="2.7" fill="#ffffff" fill-opacity="0.80"/><circle cx="157" cy="514" r="5.1" fill="#ffffff" fill-opacity="0.75"/><circle cx="314" cy="773" r="3.7" fill="#ffffff" fill-opacity="0.40"/><circle cx="428" cy="268" r="2.7" fill="#ffffff" fill-opacity="0.38"/><circle cx="569" cy="122" r="3.0" fill="#ff3b52" fill-opacity="0.90"/>
</svg>`;

let selectedPersona = null;

function selectPersonaCard(key) {
  selectedPersona = key;
  render();
}

function doLogin() {
  if (!selectedPersona) return;
  currentPersona = selectedPersona;
  const info = currentPersonaInfo();
  screen = info.defaultScreen;
  screenParams = {};
  render();
}

function LoginMain() {
  const info = selectedPersona ? PERSONAS.find(p => p.key === selectedPersona) : null;
  return h('div', { class: 'login-screen' }, [
    h('div', { class: 'login-left' }, [
      h('div', { class: 'login-bg', html: LOGIN_BG_SVG }),
      h('div', { class: 'login-left-inner' }, [
        h('div', { class: 'login-badge' }, [h('span', { class: 'logo-ring light' }), h('span', {}, 'NTT DATA')]),
        h('h1', {}, 'Turn business needs into the right solutions, faster.'),
        h('p', {}, 'Command Center brings demand intake, prioritization, and delivery planning into one place for the people who request solutions and the team who builds them.')
      ])
    ]),
    h('div', { class: 'login-right' }, [
      h('div', { class: 'login-form-wrap' }, [
        h('div', { class: 'login-logo-row' }, [h('span', { class: 'logo-ring' }), h('span', { class: 'login-brand' }, 'NTT DATA')]),
        h('h2', {}, 'Sign in to Command Center'),
        h('p', { class: 'login-sub' }, 'Choose how you will be using Command Center today.'),
        h('div', { class: 'persona-grid' }, PERSONAS.map(p => h('div', {
          class: 'persona-card' + (selectedPersona === p.key ? ' selected' : ''),
          onclick: () => selectPersonaCard(p.key)
        }, [
          h('div', { class: 'persona-icon' }, p.icon),
          h('div', { class: 'persona-title' }, p.title),
          h('div', { class: 'persona-desc' }, p.desc)
        ]))),
        h('div', { class: 'field-group' }, [h('label', {}, 'Email'), h('input', { type: 'email', placeholder: 'name@ntt.com', value: info ? (info.name.toLowerCase().replace(' ', '.') + '@ntt.com') : '' })]),
        h('div', { class: 'field-group' }, [h('label', {}, 'Password'), h('input', { type: 'password', placeholder: '••••••••' })]),
        h('button', { class: 'login-btn' + (info ? '' : ' disabled'), onclick: doLogin }, 'Sign In'),
        h('p', { class: 'login-hint' }, info ? ('Signing in as ' + info.title) : 'Select a role above to continue')
      ])
    ])
  ]);
}
