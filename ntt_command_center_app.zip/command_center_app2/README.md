# NTT DATA Command Center Demo

A self-contained HTML/CSS/JS demo of one combined Command Center app: a persona-based login screen followed by 5 screens navigable from a single top nav bar.

0. **Login** - split-screen sign-in with a Demand Requestor / NTT Data Solution Lead persona picker.
1. **Home** - portfolio status cards and a Needs Attention list.
2. **Business Processes** - searchable, filterable table of process assessments.
3. **Drafts** - searchable table of in-progress draft assessments.
4. **Demand Intake Agent** - a guided, multi-step conversational intake flow.
5. **Demand Priority Heatmap** - portfolio heatmap, filterable demand list, and a demand detail panel.

## File structure

One shared shell, one script per screen - no build step, no bundler:

```
index.html      shell: loads styles.css and all scripts in order
styles.css      shared design system for all screens
shared.js       h() render helper, persona list, top nav bar, router (goTo), shared formatting helpers
login.js        Login screen (persona picker)
home.js         Home screen
processes.js    Business Processes screen
drafts.js       Drafts screen
intake.js       Demand Intake Agent screen
heatmap.js      Demand Priority Heatmap screen
app.js          bootstraps the router and calls the active screen's render function
```

Each screen file defines its own data and render function(s) on the global scope; `app.js` just decides which one to call based on the current `screen` value. Scripts are loaded as plain `<script src="...">` tags (no ES modules), so opening `index.html` directly by double-clicking it works in every browser without hitting local-file CORS restrictions.

## What's interactive

**Login**
- Left panel: NTT DATA branding over an abstract SVG background, with a short value-proposition headline.
- Right panel: NTT DATA logo, two persona cards - **Demand Requestor** and **NTT Data Solution Lead**. Pick one to enable Sign In (email is pre-filled based on the persona for the demo).
- Signing in as **Demand Requestor** drops you on the Demand Intake Agent with a trimmed nav (Home, Drafts, Demand Intake Agent only) and the profile shows "Jordan Blake / Demand Requestor".
- Signing in as **NTT Data Solution Lead** drops you on Home with the full 5-item nav and the profile shows "Alex Morgan / Portfolio Manager".
- The power button in the top-right of the top bar logs out and returns to the login screen.

**Home**
- The 5 status cards are clickable and jump to a filtered view (Open Approvals / Draft Processes / Approved / Added to Library) on Business Processes.
- Each Needs Attention row's action button navigates to the matching record on Business Processes or Drafts and briefly highlights that row.

**Business Processes**
- Search box plus Domain / Status / Owner / Library filters narrow the 10-row process table live.
- Clicking a row opens a detail drawer with a "Start Related Demand" button that jumps to the Demand Intake Agent.

**Drafts**
- Search narrows the 6-row draft table.
- Clicking a row opens a detail drawer with a "Resume in Demand Intake Agent" button.

**Demand Intake Agent**
- Type a free-text need (or press Enter) to kick off the guided flow.
- The assistant walks through all 8 steps (Business Objective through Review & Confirm), either via quick-reply chips or free-text answers.
- The right-rail progress checklist and progress bar update live as you answer.
- Step 8 shows a summary of your answers with a Submit Demand button that posts a confirmation message and a generated demand ID.
- "New Conversation" resets the flow. Suggested prompts and Insights send a one-off question/answer without disturbing your progress. The Drafts links in the left rail jump straight to that draft.

**Demand Priority Heatmap**
- The heatmap grid shows the aggregate portfolio totals (387 demands, £98.7M).
- Clicking any domain cell (or the Total column, or a region/Grand Total row) filters the demand list below and updates the header and Est. Annual Value badge.
- Region rows (Europe, Asia Pacific, Americas) expand/collapse; Europe reveals its UK/Germany/France breakdown.
- The left filter panel (Region, Country, Domain, Priority, Quick Win, Customer Account) drives the demand list via Apply Filters / Clear All.
- The demand table has live search, pagination (5 per page), and clicking a row updates the right-side Demand Details panel with that record's metrics, executive summary, solution areas, and recommended roles.
- The dataset behind the demand list is a curated set of ~24 sample records spanning all 7 domains and 5 regions/countries, so most heatmap cells and filter combinations return at least one result.

## Run locally

Open `index.html` directly, or run:

```bash
python -m http.server 8000
```

Then open:

```text
http://localhost:8000
```

No external libraries, CDN, npm install, or build step is required.
