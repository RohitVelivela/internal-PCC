const STEP_LABELS = ['Business Objective','Need Overview','Business Context','Scope & Requirements','Value & Impact','Constraints & Dependencies','Additional Information','Review & Confirm'];

const STEPS = [
  {
    label: 'Business Objective',
    prompt: '<h3>1. What is the primary business objective or outcome you want to achieve?</h3><b>Examples:</b><ul><li>Reduce manual effort and processing time</li><li>Improve accuracy and consistency</li><li>Enhance compliance and risk management</li><li>Improve user experience</li><li>Other (please specify)</li></ul>',
    options: ['Reduce manual effort and processing time','Improve accuracy and consistency','Enhance compliance and risk management','Improve user experience','Other (please specify)']
  },
  {
    label: 'Need Overview',
    prompt: '<h3>2. Can you describe the current process and where it falls short today?</h3>',
    options: ['Manual, paper-based process','Legacy system with no automation','Fragmented across multiple tools','No process exists today','Other (please specify)']
  },
  {
    label: 'Business Context',
    prompt: '<h3>3. Which business unit does this need belong to, and what is driving the urgency?</h3>',
    options: ['Regulatory or compliance deadline','Cost reduction target','Customer or stakeholder demand','Strategic initiative','No specific urgency']
  },
  {
    label: 'Scope & Requirements',
    prompt: '<h3>4. What should be in scope for the first version, and are there must-have requirements?</h3>',
    options: ['Core workflow only (MVP)','Full end-to-end automation','Integration with existing systems required','Reporting and analytics required','Not sure yet']
  },
  {
    label: 'Value & Impact',
    prompt: '<h3>5. What impact do you expect this to have on time, cost, or risk?</h3>',
    options: ['Significant time savings (over 30%)','Moderate time savings (10-30%)','Primarily a risk or compliance benefit','Primarily a revenue or customer benefit','Not quantified yet']
  },
  {
    label: 'Constraints & Dependencies',
    prompt: '<h3>6. Are there any budget, timeline, or dependency constraints we should know about?</h3>',
    options: ['Fixed budget already approved','Hard deadline','Depends on another initiative or system','No known constraints']
  },
  {
    label: 'Additional Information',
    prompt: '<h3>7. Anything else we should capture, such as stakeholders, related systems, or attachments?</h3>',
    options: ['I have stakeholders to add','I have documents to attach','Related to an existing demand','Nothing else to add']
  },
  {
    label: 'Review & Confirm',
    prompt: null,
    options: null
  }
];

const SUGGESTED_PROMPTS = [
  { text: 'What information do you need from me?', reply: 'I will ask about your business objective, the current process, scope, expected value, constraints, and any supporting details, eight short questions in total. You can type a free-text answer at any point instead of picking an option.' },
  { text: 'What are the common solution approaches for this type of need?', reply: 'Common approaches include generative AI and document intelligence for text-heavy work, RPA and process automation for repetitive tasks, and predictive analytics for forecasting or risk scoring. I will suggest the best fit once I understand your need.' },
  { text: 'Can you show similar demands submitted by others?', reply: 'Once your demand is captured, I can surface similar demands from the portfolio on the Demand Priority Heatmap screen. Use the filters there to browse by domain, region, or account.' },
  { text: 'How long does the intake and review process take?', reply: 'Intake usually takes 5-10 minutes. After you submit, the solution and governance teams typically review within 3-5 business days.' },
  { text: 'What happens after I submit this demand?', reply: 'Your demand is added to the portfolio for triage. It gets a priority score, is routed to the right domain owner, and you will be notified when it moves to review.' }
];

const INSIGHT_PROMPTS = [
  { text: 'Similar demands and outcomes', reply: 'Similar demands in this domain have typically moved from intake to pilot within 6-8 weeks, with the strongest outcomes coming from a tightly scoped MVP.' },
  { text: 'Estimated effort and timeline', reply: 'Based on comparable demands, expect roughly 1-2 FTEs for discovery and 3-5 for build, spread over a 3-6 month first release.' },
  { text: 'Potential solution areas', reply: 'Likely solution areas include generative AI, document intelligence, and workflow automation. This will refine as you answer more questions.' },
  { text: 'Related policies and guidelines', reply: 'Check the Intake Guide for data handling, procurement, and AI governance policies relevant to this type of demand.' }
];

let messages = [];
let awaitingRawNeed = true;
let currentStepIndex = -1;
let stepAnswers = new Array(STEPS.length).fill(null);
let submitted = false;
let generatedDemandId = null;

function resetIntake() {
  messages = [{ sender: 'bot', html: '<b>Hi Alex! I am your Demand Intake Agent.</b><br><br>I will guide you through a few questions to understand your need and create a comprehensive demand.<br><br>What would you like to achieve?<div class="time">10:24 AM</div>' }];
  awaitingRawNeed = true;
  currentStepIndex = -1;
  stepAnswers = new Array(STEPS.length).fill(null);
  submitted = false;
  generatedDemandId = null;
}
resetIntake();

function IntakeSidebar() {
  const convs = [
    ['AI Contract Review Solution', 'We are looking to implement an AI...', '10:24 AM'],
    ['Supplier Risk Assessment Tool', 'Need a solution for automated...', 'Yesterday'],
    ['Intelligent Invoice Processing', 'Automate invoice capturing and...', 'May 28'],
    ['Data Privacy Compliance', 'Looking for a solution to help us...', 'May 27'],
    ['IT Service Management Platform', 'Upgrade or implement a new ITSM...', 'May 26']
  ];
  return h('aside', { class: 'sidebar' }, [
    h('div', { class: 'side-title' }, [h('span', {}, 'Demand Intake'), h('span', {}, '+')]),
    h('button', { class: 'primary-btn', onclick: () => { resetIntake(); render(); } }, '+  New Conversation'),
    h('div', { class: 'side-section' }, [
      h('h4', {}, 'Recent Conversations'),
      ...convs.map((c, i) => h('div', { class: 'conv ' + (i === 0 ? 'active' : '') }, [h('span', {}, '▣'), h('div', {}, [h('div', { class: 'conv-title' }, c[0]), h('small', {}, c[1])]), h('small', {}, c[2])])),
      h('span', { class: 'link' }, 'View all conversations')
    ]),
    h('div', { class: 'side-section' }, [
      h('h4', {}, 'Your Drafts   2'),
      h('div', { class: 'conv', onclick: () => goTo('drafts', { highlightId: 'DF-2003' }) }, [h('span', {}, '◰'), h('div', {}, [h('div', { class: 'conv-title' }, 'IT Asset Provisioning'), h('small', {}, 'Last updated 1 day ago')])]),
      h('div', { class: 'conv', onclick: () => goTo('drafts', { highlightId: 'DF-2005' }) }, [h('span', {}, '◰'), h('div', {}, [h('div', { class: 'conv-title' }, 'Vendor Risk Assessment'), h('small', {}, 'Last updated 3 days ago')])]),
      h('span', { class: 'link', onclick: () => goTo('drafts') }, 'View all drafts')
    ]),
    h('div', { class: 'side-section' }, [h('div', { class: 'help-card' }, [h('b', {}, 'Need help?'), h('div', {}, 'See guidance on how to submit a demand'), h('span', { class: 'link' }, 'View Intake Guide  ->')])])
  ]);
}

function IntakeRightRail() {
  const doneCount = submitted ? STEP_LABELS.length : Math.max(0, currentStepIndex);
  const pct = Math.round((doneCount / STEP_LABELS.length) * 100);
  return h('div', { class: 'right-rail' }, [
    h('div', { class: 'panel' }, [
      h('div', { class: 'panel-head' }, [h('h3', {}, 'Intake Progress'), h('span', { class: 'meta' }, submitted ? 'Complete' : ('Step ' + Math.max(1, currentStepIndex + 1) + ' of ' + STEP_LABELS.length))]),
      h('div', { class: 'progressbar' }, h('span', { style: 'width:' + pct + '%' })),
      ...STEP_LABELS.map((s, i) => {
        const isDone = submitted || i < currentStepIndex;
        const isActive = !submitted && i === currentStepIndex;
        return h('div', { class: 'step ' + (isDone ? 'done ' : isActive ? 'active ' : '') }, [h('span', { class: 'num' }, isDone ? '✓' : String(i + 1)), h('span', {}, s)]);
      })
    ]),
    h('div', { class: 'panel' }, [h('h3', {}, 'Suggested prompts'), ...SUGGESTED_PROMPTS.map(p => h('div', { class: 'prompt-card', onclick: () => { askAside(p.text, p.reply); } }, [h('span', {}, p.text), h('b', { class: 'blue' }, '→')]))]),
    h('div', { class: 'panel' }, [h('h3', {}, 'Insights you can ask'), ...INSIGHT_PROMPTS.map(i => h('div', { class: 'insight', onclick: () => { askAside(i.text, i.reply); } }, [h('span', { class: 'insight-icon' }, '▣'), h('span', {}, i.text)]))])
  ]);
}

function askAside(question, reply) {
  if (submitted) return;
  messages.push({ sender: 'user', html: question + '<div class="time">just now</div>' });
  messages.push({ sender: 'bot', html: reply + '<div class="time">just now</div>' });
  render();
}

function pushBotStep(index) {
  const step = STEPS[index];
  messages.push({ sender: 'bot', html: step.prompt + '<div class="time">just now</div>' });
}

function pushReviewSummary() {
  let rows = '<ul>';
  STEPS.slice(0, STEPS.length - 1).forEach((s, i) => {
    rows += '<li><b>' + s.label + ':</b> ' + (stepAnswers[i] || '-') + '</li>';
  });
  rows += '</ul>';
  messages.push({ sender: 'bot', html: '<h3>8. Review &amp; Confirm</h3>Here is a summary of what you have told me:' + rows + 'If this looks right, submit the demand for triage.<div class="time">just now</div>' });
}

function advanceIntake(answerText) {
  if (submitted) return;
  const text = (answerText || '').trim();
  if (!text) return;

  if (awaitingRawNeed) {
    messages.push({ sender: 'user', html: text + '<div class="time">just now</div>' });
    awaitingRawNeed = false;
    currentStepIndex = 0;
    messages.push({ sender: 'bot', html: 'Great! I have started capturing your need. I will ask a few questions to get more details.<br>You can answer one by one.' + STEPS[0].prompt + '<div class="time">just now</div>' });
    render();
    return;
  }

  if (currentStepIndex === STEPS.length - 1) {
    return;
  }

  messages.push({ sender: 'user', html: text + '<div class="time">just now</div>' });
  stepAnswers[currentStepIndex] = text;
  currentStepIndex++;

  if (currentStepIndex === STEPS.length - 1) {
    pushReviewSummary();
  } else {
    pushBotStep(currentStepIndex);
  }
  render();
}

function submitDemand() {
  if (submitted) return;
  generatedDemandId = 'DM-100' + (70 + STEP_LABELS.length);
  submitted = true;
  messages.push({ sender: 'bot', html: '<b>Demand submitted.</b><br><br>Your demand <b>' + generatedDemandId + '</b> has been created and added to the portfolio for triage. You can track its status from the Demand Priority Heatmap screen.<div class="time">just now</div>' });
  render();
}

function IntakeMain() {
  const showOptions = !submitted && (awaitingRawNeed ? false : (currentStepIndex >= 0 && currentStepIndex < STEPS.length - 1));
  const showSubmit = !submitted && currentStepIndex === STEPS.length - 1;
  const options = showOptions ? STEPS[currentStepIndex].options : null;

  return h('main', { class: 'main' }, [
    h('div', { class: 'intake-screen' }, [
      h('div', { class: 'chat-wrap' }, [
        h('div', { class: 'page-head' }, [h('span', { class: 'bot-icon' }, '🤖'), h('div', {}, [h('h1', {}, ['Demand Intake Agent ', h('span', { class: 'pill' }, 'Beta')]), h('p', {}, 'I will help you capture your business need and create a demand for the right solution.')])]),
        h('div', { class: 'messages' }, messages.map(m => h('div', { class: 'row ' + (m.sender === 'user' ? 'user' : '') }, m.sender === 'user' ? [h('div', { class: 'bubble user', html: m.html })] : [h('span', { class: 'bot-icon' }, '🤖'), h('div', { class: 'bubble', html: m.html })]))),
        options ? h('div', { class: 'quick-options' }, options.map(t => h('button', { class: 'option', onclick: () => advanceIntake(t) }, t))) : null,
        showSubmit ? h('div', { class: 'quick-options' }, [h('button', { class: 'option submit-option', onclick: submitDemand }, 'Submit Demand')]) : null,
        h('div', { class: 'composer' + (submitted ? ' disabled' : '') }, [
          h('span', {}, '📎'),
          h('input', {
            id: 'chat-input', placeholder: submitted ? 'This intake is complete.' : 'Type your answer or ask a follow-up question...',
            disabled: submitted ? 'true' : null,
            onkeydown: (e) => { if (e.key === 'Enter') { advanceIntake(e.target.value); e.target.value = ''; } }
          }),
          h('span', {}, '🎙'),
          h('button', {
            class: 'send', onclick: () => { const inp = document.getElementById('chat-input'); if (inp) { advanceIntake(inp.value); inp.value = ''; } }
          }, '▷')
        ]),
        h('div', { class: 'fineprint' }, 'AI-generated content may be incorrect. Please review before submitting.')
      ]),
      IntakeRightRail()
    ])
  ]);
}
