/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // semantic tokens — every screen uses these so light/dark just works
        page: 'var(--page)',
        surface: 'var(--surface-1)',
        'surface-2': 'var(--surface-2)',
        elevated: 'var(--elevated)',
        ink: 'var(--ink)',
        'ink-2': 'var(--ink-2)',
        muted: 'var(--muted)',
        grid: 'var(--grid)',
        'grid-strong': 'var(--grid-strong)',
        baseline: 'var(-