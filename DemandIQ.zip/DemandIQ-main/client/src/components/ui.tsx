import type { Band, DemandType } from '../types';
import { TYPE_COLORS, TYPE_LABELS } from '../types';

const BAND_COLOR: Record<Band, string> = {
  High: 'var(--critical)',
  Medium: 'var(--warning)',
  Low: 'var(--good)',
};

export function bandColor(b: Band): string {
  return BAND_COLOR[b];
}

/* Pills tint by mixing the accent with the current surface / ink so they read
   correctly in both light and dark themes (never hard-coded white/black). */
export function Pill({ label, color }: { label: string; color: string }) {
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium"
      style={{
        background: `color-mix(in srgb, ${color} 16%, var(--surface-1))`,
        color: `color-mix(in srgb, ${color} 62%, var(--ink))`,
      }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
      {label}
    </span>
  );
}

export function PriorityPill({ band }: { band: Band }) {
  return <Pill label={`${band} priority`} color={BAND_COLOR[band]} />;
}

export function YesNoPill({ yes }: { yes: boolean }) {
  return <Pill label={yes ? 'Yes' : 'No'} color={yes ? 'var(--good)' : 'var(--muted)'} />;
}

export function TypeChip({ type }: { type?: DemandType }) {
  if (!type) return null;
  const color = TYPE_COLORS[type];
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium"
      style={{
        background: `color-mix(in srgb, ${color} 15%, var(--surface-1))`,
        color: `color-mix(in srgb, ${color} 60%, var(--ink))`,
      }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
      {TYPE_LABELS[type]}
    </span>
  );
}

export function StatusPill({ status }: { status: string }) {
  const submitted = status === 'Submitted';
  const draft = status === 'Draft';
  const color = submitted ? 'var(--good)' : draft ? 'var(--warning)' : 'var(--brand)';
  return (
    <span
      className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium"
      style={{
   