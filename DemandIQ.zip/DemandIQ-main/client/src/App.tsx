import { useEffect, useRef, useState, type ReactNode } from 'react';
import { api } from './api';
import type { MockUser } from './types';
import { ChatView } from './components/ChatView';
import { PrioritisationDashboard } from './prioritisation/PrioritisationDashboard';
import { ActionLog } from './components/ActionLog';
import { NttLogo } from './components/Brand';
import { useTheme } from './theme';

type View = 'new' | 'tracker' | 'log';

const TABS: { id: View; label: string; icon: ReactNode; muted?: boolean }[] = [
  { id: 'new', label: 'Demand Intake', icon: <IntakeIcon /> },
  { id: 'tracker', label: 'Demand Tracker', icon: <GridIcon /> },
  { id: 'log', label: 'Agent Action Log', icon: <LogIcon />, muted: true },
];

export default function App() {
  const [users, setUsers] = useState<MockUser[]>([]);
  const [userId, setUserId] = useState('');
  const [view, setView] = useState<View>('new');
  const [activeConv, setActiveConv] = useState<string | null>(null);
  const [simFail, setSimFail] = useState(false);
  const [refresh, setRefresh] = useState(0);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const { theme, toggle } = useTheme();
  const settingsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    api.users().then((u) => {
      setUsers(u);
      setUserId(u[0]?.id ?? '');
    });
    api.getDebug().then((d) => setSimFail(d.failNextSubmit));
  }, []);

  // close the settings popover on outside click
  useEffect(() => {
    if (!settingsOpen) return;
    function onClick(e: MouseEvent) {
      if (settingsRef.current && !settingsRef.current.contains(e.target as Node))
        setSettingsOpen(false);
    }
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, [settingsOpen]);

  const user = users.find((u) => u.id === userId);

  function switchUser(id: string) {
    setUserId(id);
    setActiveConv(null);
    setView('new');
    setRefresh((r) => r + 1);
  }

  function startNew() {
    setActiveConv(null);
    setView('new');
    setRefresh((r) => r + 1);
  }

  async function toggleSimFail() {
    const next = !simFail;
    setSimFail(next);
    await api.setSimulateFailure(next);
  }

  return (
    <div className="flex h-full flex-col bg-page text-ink">
      {/* ── Top bar: brand · page title · user · theme · settings ── */}
      <header className="glass sticky top-0 z-20 flex items-center gap-4 border-b border-grid px-6 py-3">
        <div className="flex items-center gap-3">
          <div className="flex h-8 items-center rounded-lg px-1">
            <NttLogo height={20} />
          </div>
          <span className="h-6 w-px bg-grid" />
          <div className="leading-tight">
            <div className="text-sm font-semibold tracking-tight">DemandIQ</div>
            <div className="text-[11px] text-muted">Delivery Command Center</div>
          </div>
        </div>

        <div className="ml-1 hidden border-l border-grid pl-4 leading-tight sm:block">
          <h1 className="text-sm font-semibold">{viewTitle(view)}</h1>
          <p className="text-[11px] text-muted">AI-assisted demand intake</p>
        </div>

        <div className="ml-auto flex items-center gap-2.5">
          <div className="hidden text-right leading-tight md:block">
            <div className="text-[11px] text-muted">{user?.persona ?? 'Signed in as'}</div>
            <div className="text-sm font-medium">
              {user?.name}
              {user?.orgName ? ` · ${user.orgName}` : ''}
            </div>
          </div>
          <div className="relative">
            <select
              value={userId}
              onChange={(e) => switchUser(e.target.value)}
              className="max-w-[13rem] appearance-none truncate rounded-full border border-grid bg-surface-2 py-2 pl-3.5 pr-8 text-sm text-ink-2 transition hover:border-grid-strong"
            >
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.persona} — {u.name} ({u.orgName})
                </option>
              ))}
            </select>
            <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-muted" />
          </div>

          <IconButton onClick={toggle} title={theme === 'dark' ? 'Switch to light' : 'Switch to dark'}>
            {theme === 'dark' ? <SunIcon /> : <MoonIcon />}
          </IconButton>

          <div className="relative" ref={settingsRef}>
            <IconButton
              onClick={() => setSettingsOpen((o) => !o)}
              title="Settings"
              active={settingsOpen}
            >
              <GearIcon />
            </IconButton>
            {settingsOpen && (
              <div className="absolute right-0 z-30 mt-2 w-72 rounded-2xl border border-grid bg-elevated p-4 shadow-lg">
                <div className="text-[11px] font-semibold uppercase tracking-wide text-muted">
                  Developer
                </div>
                <label className="mt-2.5 flex items-center justify-between gap-2 text-sm text-ink-2">
                  <span>Simulate API failure</span>
                  <Toggle on={simFail} onClick={toggleSimFail} danger />
                </label>
                <p className="mt-2 text-[11px] leading-snug text-muted">
                  Forces the next “Confirm &amp; submit” to fail once, to demo the error / retry path.
                </p>
                <div className="my-3 h-px bg-grid" />
                <label className="flex items-center justify-between gap-2 text-sm text-ink-2">
                  <span>Dark appearance</span>
                  <Toggle on={theme === 'dark'} onClick={toggle} />
                </label>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* ── Segmented tab bar ── */}
      <nav className="border-b border-grid bg-surface px-4 py-2">
        <div className="inline-flex items-center gap-1 rounded-full bg-page p-1">
          {TABS.map((t) => (
            <TabItem
              key={t.id}
              label={t.label}
              icon={t.icon}
              active={view === t.id}
              muted={t.muted}
              onClick={t.id === 'new' ? startNew : () => setView(t.id)}
            />
          ))}
        </div>
      </nav>

      {/* ── Main ── */}
      <div className="flex flex-1 flex-col overflow-hidden">
        <main className="flex flex-1 flex-col overflow-hidden bg-page">
          {user && view === 'new' && (
            <div className="min-h-0 flex-1 overflow-hidden">
              <ChatView
                key={`${userId}:${activeConv ?? 'fresh'}:${refresh}`}
                user={user}
                conversationId={activeConv}
                refreshKey={refresh}
                onConversationCreated={setActiveConv}
                onNewConversation={startNew}
                onOpenConversation={(id) => {
                  se