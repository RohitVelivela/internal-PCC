/** @type {import('tailwindcss').Config} */
import { nextui } from '@nextui-org/react';

export default {
  darkMode: 'class',
  content: [
    './index.html',
    './src/**/*.{ts,tsx}',
    './node_modules/@nextui-org/theme/dist/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        // semantic tokens — every screen uses these so light/dark just works
        page: 'var(--page)',
        surface: 'var(--surface-1)',
        'surface-2': 'var(--surface-2)',
        elevated: 'var(--elevated)',
        ink: 'var(--ink)',
        'ink-2': 'var(--ink-2)',
        muted: 'var(--muted)',
        grid: 'var(--grid)',
        'grid-strong': 'var(--grid-strong)',
        baseline: 'var(--baseline)',
        border: 'var(--border)',
        brand: 'var(--brand)',
        'brand-deep': 'var(--brand-deep)',
        'brand-soft': 'var(--brand-soft)',
        'on-brand': 'var(--on-brand)',
        good: 'var(--good)',
        warning: 'var(--warning)',
        critical: 'var(--critical)',
      },
    },
  },
  plugins: [nextui()],
};