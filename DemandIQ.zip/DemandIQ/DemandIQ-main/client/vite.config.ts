import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { mockApiPlugin } from './mock-api';

export default defineConfig({
  plugins: [react(), mockApiPlugin()],
  server: {
    port: 5173,
    host: true,
    // Allow any Host header so public tunnels (ngrok/cloudflare) aren't blocked.
    allowedHosts: true,
  },
});
