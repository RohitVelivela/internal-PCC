import type { Plugin } from 'vite';
import type { IncomingMessage, ServerResponse } from 'http';

/* ── In-memory store ──────────────────────────────────────── */
interface Conversation {
  id: string; userId: string; orgId: string;
  status: 'Active' | 'Draft' | 'Submitted'; step: string;
  demandType?: string; pendingField?: string;
  messages: { id: string; role: string; text: string; ts: string }[];
  title: string; createdAt: string; updatedAt: string;
  submittedItemId?: string;
}
interface DemandItem {
  id: string; title: string; demandType: string; description: string;
  businessArea: string; businessProblem: string; expectedValue: string;
  proposedTimeline: string; submitterId: string; customerOrgId: string;
  sourceChannel: string; status: string; duplicateReferences: unknown[];
  conditionalFields: Record<string, string>; roi: Record<string, string>;
  createdAt: string; updatedAt: string;
  scoring?: {
    priorityScore: number; priorityBand: string; estAnnualValue: number;
    quickWin: boolean; strategicBet: boolean; roiPotential: number;
    ease: string; businessValue: string; strategicImpact: string;
    strategicFit: string; confidence: string;
  };
}

const conversations = new Map<string, Conversation>();
const demands = new Map<string, DemandItem>();
let failNextSubmit = false;

const USERS = [
  { id: 'u1', name: 'Alice Johnson', role: 'Business Analyst', persona: 'Customer submitter', orgId: 'org1', orgName: 'NHS Digital' },
  { id: 'u2', name: 'Bob Smith', role: 'Solution Lead', persona: 'NTT DATA Solution Lead', orgId: 'org1', orgName: 'NHS Digital' },
  { id: 'u3', name: 'Carol White', role: 'Sponsor', persona: 'Customer approver / sponsor', orgId: 'org2', orgName: 'Barclays' },
  { id: 'u4', name: 'Dan Brown', role: 'Admin', persona: 'Platform Administrator', orgId: 'org2', orgName: 'Barclays' },
];

function uid() { return Math.random().toString(36).slice(2, 10); }
function now() { return new Date().toISOString(); }

const INTAKE_QUESTIONS = [
  "Thanks for reaching out! To get started, could you briefly describe the business problem you're trying to solve?",
  "Great. What business objective does this support — e.g. cost reduction, revenue growth, compliance?",
  "Who are the primary users or stakeholders affected by this?",
  "Do you have a rough timeline or deadline in mind for this initiative?",
  "What would success look like? Any measurable outcomes or KPIs?",
  "Are there any known constraints, dependencies, or risks we should be aware of?",
  "Almost done! Any additional context, attachments, or supporting material you'd like to add?",
];

function buildView(conv: Conversation) {
  const stepIndex = ['classify','confirm_type','questioning','duplicate_decision','confirmation','submitted'].indexOf(conv.step);
  const canSubmit = conv.step === 'confirmation';
  return {
    conversation: conv,
    quickReplies: conv.step === 'questioning' ? [
      { label: 'Skip this question', value: 'Skip' },
      { label: 'Need help', value: 'What do you mean?' },
    ] : [],
    missingMandatory: [],
    canSubmit,
    summary: canSubmit ? [
      { group: 'Overview', fields: [
        { label: 'Title', value: conv.title },
        { label: 'Type', value: conv.demandType ?? 'new_ai_use_case' },
        { label: 'Status', value: conv.status },
      ]},
    ] : undefined,
    editableFields: canSubmit ? [
      { key: 'title', label: 'Title', value: conv.title, type: 'text', group: 'Overview' },
      { key: 'demandType', label: 'Demand Type', value: conv.demandType ?? 'new_ai_use_case',
        type: 'choice', options: ['new_ai_use_case','enhancement','capacity_request','exploratory'], group: 'Overview' },
    ] : undefined,
  };
}

function agentReply(conv: Conversation, userText: string): string {
  const msgCount = conv.messages.filter(m => m.role === 'user').length;
  if (conv.step === 'classify') {
    const lower = userText.toLowerCase();
    if (lower.includes('ai') || lower.includes('automation')) {
      conv.demandType = 'new_ai_use_case';
    } else if (lower.includes('enhance') || lower.includes('improve')) {
      conv.demandType = 'enhancement';
    } else if (lower.includes('capacity') || lower.includes('resource')) {
      conv.demandType = 'capacity_request';
    } else {
      conv.demandType = 'exploratory';
    }
    conv.step = 'questioning';
    return `Thanks! I've classified this as a **${conv.demandType.replace(/_/g,' ')}** request. Let's gather a bit more detail.\n\n${INTAKE_QUESTIONS[0]}`;
  }
  if (conv.step === 'questioning') {
    const idx = Math.min(msgCount - 1, INTAKE_QUESTIONS.length - 1);
    if (idx >= INTAKE_QUESTIONS.length - 1) {
      conv.step = 'confirmation';
      return "Great, I have everything I need! Here's a summary of your demand request. Please review the details below — you can edit any field before submitting.";
    }
    return INTAKE_QUESTIONS[idx] ?? "Can you tell me more about that?";
  }
  return "I've noted that. Is there anything else you'd like to add?";
}

/* ── Route handlers ───────────────────────────────────────── */
function handleRequest(req: IncomingMessage, res: ServerResponse, body: string) {
  const url = new URL(req.url ?? '/', `http://localhost`);
  const path = url.pathname;
  const method = (req.method ?? 'GET').toUpperCase();

  function json(data: unknown, status = 200) {
    res.writeHead(status, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(data));
  }

  // GET /api/users
  if (method === 'GET' && path === '/api/users') {
    return json(USERS);
  }

  // GET /api/debug
  if (method === 'GET' && path === '/api/debug') {
    return json({ failNextSubmit });
  }

  // POST /api/debug/simulate-failure
  if (method === 'POST' && path === '/api/debug/simulate-failure') {
    const parsed = body ? JSON.parse(body) : {};
    failNextSubmit = parsed.enabled ?? false;
    return json({ failNextSubmit });
  }

  // GET /api/conversations?userId=...
  if (method === 'GET' && path === '/api/conversations') {
    const userId = url.searchParams.get('userId') ?? '';
    const list = [...conversations.values()]
      .filter(c => !userId || c.userId === userId)
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
      .map(c => ({
        id: c.id, title: c.title, status: c.status, step: c.step,
        demandType: c.demandType, submittedItemId: c.submittedItemId,
        updatedAt: c.updatedAt, messageCount: c.messages.length,
      }));
    return json(list);
  }

  // POST /api/conversations
  if (method === 'POST' && path === '/api/conversations') {
    const parsed = body ? JSON.parse(body) : {};
    const user = USERS.find(u => u.id === parsed.userId) ?? USERS[0];
    const id = uid();
    const conv: Conversation = {
      id, userId: user.id, orgId: user.orgId,
      status: 'Active', step: 'classify',
      messages: [{
        id: uid(), role: 'agent', ts: now(),
        text: "Hello! I'm the DemandIQ intake assistant. I'll help you capture and shape your demand request.\n\nPlease start by describing what you'd like to achieve or the problem you're trying to solve.",
      }],
      title: 'New demand', createdAt: now(), updatedAt: now(),
    };
    conversations.set(id, conv);
    return json(buildView(conv));
  }

  // GET /api/conversations/:id
  const convMatch = path.match(/^\/api\/conversations\/([^/]+)$/);
  if (method === 'GET' && convMatch) {
    const conv = conversations.get(convMatch[1]);
    if (!conv) return json({ error: 'Not found' }, 404);
    return json(buildView(conv));
  }

  // PATCH /api/conversations/:id (rename)
  if (method === 'PATCH' && convMatch) {
    const conv = conversations.get(convMatch[1]);
    if (!conv) return json({ error: 'Not found' }, 404);
    const parsed = body ? JSON.parse(body) : {};
    if (parsed.title) conv.title = parsed.title;
    conv.updatedAt = now();
    return json({ id: conv.id, title: conv.title });
  }

  // DELETE /api/conversations/:id
  if (method === 'DELETE' && convMatch) {
    conversations.delete(convMatch[1]);
    return json({ ok: true });
  }

  // POST /api/conversations/:id/messages
  const msgMatch = path.match(/^\/api\/conversations\/([^/]+)\/messages$/);
  if (method === 'POST' && msgMatch) {
    const conv = conversations.get(msgMatch[1]);
    if (!conv) return json({ error: 'Not found' }, 404);
    const parsed = body ? JSON.parse(body) : {};
    const userMsg = { id: uid(), role: 'user', text: parsed.text ?? '', ts: now() };
    conv.messages.push(userMsg);
    const reply = agentReply(conv, parsed.text ?? '');
    conv.messages.push({ id: uid(), role: 'agent', text: reply, ts: now() });
    // Update title from first user message
    if (conv.title === 'New demand' && parsed.text) {
      conv.title = parsed.text.slice(0, 60) + (parsed.text.length > 60 ? '…' : '');
    }
    conv.updatedAt = now();
    return json(buildView(conv));
  }

  // POST /api/conversations/:id/draft
  const draftMatch = path.match(/^\/api\/conversations\/([^/]+)\/draft$/);
  if (method === 'POST' && draftMatch) {
    const conv = conversations.get(draftMatch[1]);
    if (!conv) return json({ error: 'Not found' }, 404);
    conv.status = 'Draft';
    conv.updatedAt = now();
    return json(buildView(conv));
  }

  // POST /api/conversations/:id/submit
  const submitMatch = path.match(/^\/api\/conversations\/([^/]+)\/submit$/);
  if (method === 'POST' && submitMatch) {
    if (failNextSubmit) { failNextSubmit = false; return json({ error: 'Simulated failure' }, 500); }
    const conv = conversations.get(submitMatch[1]);
    if (!conv) return json({ error: 'Not found' }, 404);
    const parsed = body ? JSON.parse(body) : {};
    if (parsed.edits) Object.assign(conv, parsed.edits);
    const itemId = `DEM-${uid().toUpperCase()}`;
    conv.status = 'Submitted'; conv.step = 'submitted';
    conv.submittedItemId = itemId; conv.updatedAt = now();
    conv.messages.push({ id: uid(), role: 'agent', ts: now(),
      text: `Your demand has been submitted successfully! Your reference number is **${itemId}**. Our team will review it within 2-3 business days.` });
    const item: DemandItem = {
      id: itemId, title: conv.title,
      demandType: (conv.demandType as string) ?? 'new_ai_use_case',
      description: '', businessArea: '', businessProblem: '', expectedValue: '',
      proposedTimeline: '', submitterId: conv.userId, customerOrgId: conv.orgId,
      sourceChannel: 'webchat', status: 'Submitted',
      duplicateReferences: [], conditionalFields: {}, roi: {},
      createdAt: conv.createdAt, updatedAt: now(),
      scoring: {
        priorityScore: Math.floor(Math.random() * 40 + 60),
        priorityBand: 'High', estAnnualValue: Math.floor(Math.random() * 500000 + 100000),
        quickWin: Math.random() > 0.5, strategicBet: Math.random() > 0.5,
        roiPotential: Math.floor(Math.random() * 40 + 60),
        ease: 'Medium', businessValue: 'High', strategicImpact: 'High',
        strategicFit: 'High', confidence: 'Medium',
      },
    };
    demands.set(itemId, item);
    return json({ item, view: buildView(conv) });
  }

  // GET /api/demands?userId=...
  if (method === 'GET' && path === '/api/demands') {
    const userId = url.searchParams.get('userId') ?? '';
    const list = [...demands.values()].filter(d => !userId || d.submitterId === userId);
    return json(list);
  }

  // GET /api/action-log?conversationId=...
  if (method === 'GET' && path === '/api/action-log') {
    const convId = url.searchParams.get('conversationId') ?? '';
    const conv = conversations.get(convId);
    const entries = conv ? [
      { id: uid(), conversationId: convId, actionType: 'conversation_started', detail: 'Conversation initiated', timestamp: conv.createdAt, userId: conv.userId },
      ...(conv.status === 'Submitted' ? [{ id: uid(), conversationId: convId, actionType: 'demand_submitted', detail: `Demand submitted: ${conv.submittedItemId}`, timestamp: conv.updatedAt, userId: conv.userId }] : []),
    ] : [];
    return json(entries);
  }

  // POST /api/assistant
  if (method === 'POST' && path === '/api/assistant') {
    const parsed = body ? JSON.parse(body) : {};
    const last = (parsed.messages ?? []).at(-1)?.text ?? '';
    const replies: Record<string, string> = {
      'similar': 'I found 3 similar demands in the system: "AI chatbot for HR queries" (submitted 2 months ago), "Automated invoice processing" (approved), and "Predictive maintenance dashboard" (under review).',
      'timeline': 'Typically, demand reviews take 5–10 business days. After approval, delivery scoping takes another 2–4 weeks.',
      'after': 'After submission, your demand enters the review queue. A Solution Lead will be assigned and will contact you within 2 business days.',
      'effort': 'Based on similar demands, this type of initiative typically requires 3–6 months and a team of 4–8 people.',
    };
    const reply = Object.entries(replies).find(([k]) => last.toLowerCase().includes(k))?.[1]
      ?? "I'm here to help with your demand request. You can ask me about similar demands, typical timelines, what happens after submission, or estimated effort.";
    return json({ reply });
  }

  return null; // not handled
}

/* ── Vite plugin ──────────────────────────────────────────── */
export function mockApiPlugin(): Plugin {
  return {
    name: 'mock-api',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        if (!req.url?.startsWith('/api')) return next();
        let body = '';
        req.on('data', chunk => { body += chunk; });
        req.on('end', () => {
          const handled = handleRequest(req, res, body);
          if (handled === null) next();
        });
      });
    },
  };
}
