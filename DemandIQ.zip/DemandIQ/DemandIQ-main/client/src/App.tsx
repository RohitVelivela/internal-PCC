import { useEffect, useState, type ReactNode } from 'react';
import { api } from './api';
import type { MockUser } from './types';
import { ChatView } from './components/ChatView';
import { PrioritisationDashboard } from './prioritisation/PrioritisationDashboard';
import { ActionLog } from './components/ActionLog';
import { ConversationSidebar, type View } from './components/ConversationSidebar';
import { UserMenu } from './components/UserMenu';
import { NttLogo } from './components/Brand';

export default function App() {
  const [users, setUsers] = useState<MockUser[]>([]);
  const [userId, setUserId] = useState('');
  const [view, setView] = useState<View>('new');
  const [activeConv, setActiveConv] = useState<string | null>(null);
  const [refresh, setRefresh] = useState(0);
  const [sidebarRefresh, setSidebarRefresh] = useState(0);
  const [collapsed, setCollapsed] = useState(false);

  useEffect(() => {
    api.users().then((u) => { setUsers(u); setUserId(u[0]?.id ?? ''); });
  }, []);

  const user = users.find((u) => u.id === userId);

  function bumpSidebar() { setSidebarRefresh((r) => r + 1); }
  function startNew() { setActiveConv(null); setView('new'); setRefresh((r) => r + 1); bumpSidebar(); }
  function switchUser(id: string) { setUserId(id); setActiveConv(null); setView('new'); setRefresh((r) => r + 1); bumpSidebar(); }
  function openConversation(id: string) { setActiveConv(id); setView('new'); }
  function conversationCreated(id: string) { setActiveConv(id); bumpSidebar(); }

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-[var(--page)]">
      {/* ── Global header — brand, navigation, account (every view) ──── */}
      {user && (
        <header className="z-30 flex h-14 shrink-0 items-center gap-1 border-b border-[var(--grid)] bg-[var(--surface-1)] px-4">
          <div className="flex items-center pr-8">
            <NttLogo height={19} />
          </div>

          <TopNav view={view} onSetView={setView} />

          <div className="flex-1" />

          <div className="mx-2 h-5 w-px bg-[var(--grid)]" />
          <UserMenu user={user} users={users} onSwitchUser={switchUser} />
        </header>
      )}

      {/* ── Body: sidebar (Demand Intake only) + active view ──────────── */}
      <div className="flex min-h-0 flex-1 overflow-hidden">
        {user && view === 'new' && (
          <ConversationSidebar
            userId={user.id}
            activeConv={activeConv}
            onNewChat={startNew}
            onOpenConversation={openConversation}
            onDeleteActive={startNew}
            refreshKey={sidebarRefresh}
            collapsed={collapsed}
            onToggleCollapse={() => setCollapsed((c) => !c)}
          />
        )}

        <div className="min-w-0 flex-1 overflow-hidden">
          {!user ? (
            <div className="grid h-full place-items-center text-sm text-[var(--muted)]">Loading&hellip;</div>
          ) : view === 'new' ? (
            <ChatView
              key={`${userId}:${activeConv ?? 'fresh'}:${refresh}`}
              user={user}
              conversationId={activeConv}
              onConversationCreated={conversationCreated}
              onSubmitted={() => { setRefresh((r) => r + 1); bumpSidebar(); }}
              onActivity={bumpSidebar}
            />
          ) : view === 'tracker' ? (
            <PrioritisationDashboard key={`tracker:${userId}`} />
          ) : (
            <ActionLog user={user} activeConversationId={activeConv} />
          )}
        </div>
      </div>
    </div>
  );
}

/* Clean underline-tab navigation — sits beside the brand mark in the header. */
function TopNav({ view, onSetView }: { view: View; onSetView: (v: View) => void }) {
  const items: { id: View; label: string; icon: ReactNode }[] = [
    { id: 'new', label: 'Demand Intake', icon: <ChatIcon /> },
    { id: 'tracker', label: 'Demand Tracker', icon: <GridIcon /> },
    { id: 'log', label: 'Action Log', icon: <ListIcon /> },
  ];
  return (
    <nav className="flex h-14 items-stretch">
      {items.map((it) => {
        const active = view === it.id;
        return (
          <button key={it.id} onClick={() => onSetView(it.id)}
            className={`relative flex items-center gap-1.5 px-3 text-[13px] font-medium transition-colors ${
              active ? 'text-[var(--ink)]' : 'text-[var(--muted)] hover:text-[var(--ink-2)]'
            }`}>
            {it.icon}
            <span className="hidden sm:inline">{it.label}</span>
            <span className={`absolute inset-x-2 -bottom-px h-[2px] rounded-full transition-all ${active ? 'bg-[var(--brand)]' : 'bg-transparent'}`} />
          </button>
        );
      })}
    </nav>
  );
}

function ChatIcon() {
  return <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>;
}
function GridIcon() {
  return <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>;
}
function ListIcon() {
  return <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>;
}
