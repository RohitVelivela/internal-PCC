import { useEffect, useRef, useState } from 'react';
import { Chip, Progress, Textarea, Tooltip } from '@nextui-org/react';
import { api } from '../api';
import type { ConversationStep, ConversationView, MockUser } from '../types';
import { TypeChip } from './ui';
import { ConfirmationCard } from './ConfirmationCard';
import { DuplicateCard } from './DuplicateCard';

const INTAKE_STEPS = [
  'Business Objective','Need Overview','Business Context','Scope & Requirements',
  'Value & Impact','Constraints & Dependencies','Additional Information','Review & Confirm',
];
const SUGGESTED_PROMPTS = [
  'What information do you need?',
  'What are common solution approaches?',
  'Show similar demands submitted before',
  'How long does the review process take?',
  'What happens after I submit?',
];
const INSIGHTS = [
  'Similar demands & outcomes','Estimated effort & timeline',
  'Potential solution areas','Related policies',
];

export function ChatView({
  user, conversationId, onConversationCreated, onSubmitted, onActivity,
}: {
  user: MockUser; conversationId: string | null;
  onConversationCreated: (id: string) => void; onSubmitted: (itemId: string) => void;
  onActivity: () => void;
}) {
  const [view, setView] = useState<ConversationView | null>(null);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [attachments, setAttachments] = useState<string[]>([]);
  const threadRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const started = useRef(false);

  function onFilesPicked(e: React.ChangeEvent<HTMLInputElement>) {
    const names = Array.from(e.target.files ?? []).map((f) => f.name);
    if (names.length) setAttachments((prev) => [...prev, ...names]);
    e.target.value = '';
  }

  useEffect(() => {
    if (started.current) return; started.current = true;
    (async () => {
      try {
        const v = conversationId ? await api.getConversation(conversationId) : await api.startConversation(user.id);
        setView(v);
        if (!conversationId) onConversationCreated(v.conversation.id);
      } catch (e) { setError((e as Error).message); }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    threadRef.current?.scrollTo({ top: threadRef.current.scrollHeight, behavior: 'smooth' });
  }, [view?.conversation.messages.length, busy]);

  const c = view?.conversation;

  async function send(text: string) {
    let t = text.trim();
    if ((!t && attachments.length === 0) || busy || !c) return;
    if (attachments.length) { t = (t ? t + '\n\n' : '') + `Attached: ${attachments.join(', ')}`; setAttachments([]); }
    setInput(''); setBusy(true); setError(null);
    setView((v) => v ? { ...v, conversation: { ...v.conversation, messages: [...v.conversation.messages,
      { id: `local-${Date.now()}`, role: 'user', text: t, ts: new Date().toISOString() }] } } : v);
    try { const next = await api.sendMessage(c.id, t); setView(next); onActivity(); }
    catch (e) { setError((e as Error).message); try { setView(await api.getConversation(c.id)); } catch {} }
    finally { setBusy(false); }
  }

  async function handleSubmit(edits: Record<string, string>, consent: boolean) {
    if (submitting || !c) return; setSubmitting(true); setSubmitError(null);
    try { const res = await api.submit(c.id, { edits, consent, idempotencyKey: c.id }); setView(res.view); onSubmitted(res.item.id); }
    catch (e) { setSubmitError((e as Error).message); } finally { setSubmitting(false); }
  }

  async function handleSaveDraft() {
    if (!c) return;
    try { setView(await api.saveDraft(c.id)); onActivity(); } catch (e) { setError((e as Error).message); }
  }

  return (
    <div className="flex h-full w-full overflow-hidden">

      {/* ── Chat center ─────────────────────────────────────────────── */}
      <section className="flex min-w-0 flex-1 flex-col overflow-hidden bg-[var(--page)]">

        {/* Agent header — aligned with the centered chat column */}
        <div className="shrink-0 border-b border-[var(--grid)] bg-[var(--surface-1)]/80 px-6 py-2.5 backdrop-blur-sm">
          <div className="mx-auto flex w-full max-w-3xl items-center justify-center gap-3">
            <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-[var(--grid)] bg-[var(--surface-1)] text-[var(--ink)] shadow-sm">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="4" y="8" width="16" height="12" rx="3"/>
                <path d="M12 8V4M9 4h6"/>
                <circle cx="9" cy="14" r="1" fill="currentColor" stroke="none"/>
                <circle cx="15" cy="14" r="1" fill="currentColor" stroke="none"/>
              </svg>
            </div>
            <span className="text-[14px] font-semibold text-[var(--ink)]">Demand Intake</span>
            {c && c.step !== 'submitted' && (
              <button disabled={busy} onClick={handleSaveDraft}
                className="ml-auto flex items-center gap-1 rounded-lg border border-[var(--grid)] bg-[var(--page)] px-2.5 py-1 text-[11.5px] font-medium text-[var(--muted)] transition hover:border-[var(--grid-strong)] hover:text-[var(--ink-2)] disabled:opacity-40">
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                Save draft
              </button>
            )}
          </div>
        </div>

        {/* Messages */}
        {!view || !c ? (
          <div className="grid flex-1 place-items-center">
            {error ? <Chip color="danger" variant="flat">{error}</Chip>
              : <div className="flex flex-col items-center gap-3 text-sm text-[var(--muted)]">
                  <Progress isIndeterminate size="sm" className="w-36" classNames={{ indicator: 'bg-[var(--brand)]', track: 'bg-[var(--grid)]' }} />
                  <span>Starting&hellip;</span>
                </div>}
          </div>
        ) : (
          <>
            <div ref={threadRef} className="flex-1 overflow-y-auto">
              <div className="mx-auto w-full max-w-3xl space-y-5 px-6 py-6">
              {c.messages.map((m) => (
                <div key={m.id} className={`flex items-end gap-2.5 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  {m.role !== 'user' && (
                    <div className="shrink-0 h-7 w-7 rounded-full bg-gradient-to-br from-[var(--blue)] to-[var(--blue-600)] flex items-center justify-center text-white shadow-sm">
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 8V4M9 4h6"/>
                        <circle cx="9" cy="14" r="1" fill="currentColor" stroke="none"/>
                        <circle cx="15" cy="14" r="1" fill="currentColor" stroke="none"/>
                      </svg>
                    </div>
                  )}
                  <div className={`max-w-[72%] ${m.role === 'user' ? 'items-end' : 'items-start'} flex flex-col gap-1`}>
                    <div className={`rounded-2xl px-4 py-2.5 text-[13.5px] leading-relaxed shadow-sm ${
                      m.role === 'user'
                        ? 'rounded-br-sm bg-[var(--brand)] text-white'
                        : 'rounded-bl-sm bg-[var(--surface-1)] text-[var(--ink)] border border-[var(--grid)]'
                    }`}>
                      <p className="whitespace-pre-wrap">{m.text}</p>
                    </div>
                    <span className="px-1 text-[11px] text-[var(--muted)]">{fmtTime(m.ts)}</span>
                  </div>
                  {m.role === 'user' && (
                    <div className="shrink-0 h-7 w-7 rounded-full bg-[var(--brand-soft)] flex items-center justify-center text-[11px] font-bold text-[var(--brand)]">
                      {user.name.charAt(0)}
                    </div>
                  )}
                </div>
              ))}

              {busy && (
                <div className="flex items-end gap-2.5">
                  <div className="shrink-0 h-7 w-7 rounded-full bg-gradient-to-br from-[var(--blue)] to-[var(--blue-600)] flex items-center justify-center text-white shadow-sm">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 8V4M9 4h6"/>
                      <circle cx="9" cy="14" r="1" fill="currentColor" stroke="none"/>
                      <circle cx="15" cy="14" r="1" fill="currentColor" stroke="none"/>
                    </svg>
                  </div>
                  <div className="rounded-2xl rounded-bl-sm bg-[var(--surface-1)] border border-[var(--grid)] px-4 py-3 shadow-sm">
                    <div className="flex items-center gap-1">
                      <span className="h-1.5 w-1.5 rounded-full bg-[var(--muted)] animate-bounce [animation-delay:0ms]"/>
                      <span className="h-1.5 w-1.5 rounded-full bg-[var(--muted)] animate-bounce [animation-delay:120ms]"/>
                      <span className="h-1.5 w-1.5 rounded-full bg-[var(--muted)] animate-bounce [animation-delay:240ms]"/>
                    </div>
                  </div>
                </div>
              )}

              {view.duplicateCandidate && c.step === 'duplicate_decision' && (
                <DuplicateCard candidate={view.duplicateCandidate} matchType={c.duplicate?.matchType} rationale={c.duplicate?.rationale} />
              )}
              {c.step === 'confirmation' && (
                <ConfirmationCard view={view} submitting={submitting} submitError={submitError} onSubmit={handleSubmit} onSaveDraft={handleSaveDraft} />
              )}
              </div>
            </div>

            {/* Composer */}
            {c.step === 'submitted' ? (
              <div className="shrink-0 px-6 pb-5">
                <div className="mx-auto flex w-full max-w-3xl items-center justify-center gap-2 rounded-2xl bg-[color-mix(in_srgb,var(--good)_12%,var(--surface-1))] border border-[color-mix(in_srgb,var(--good)_25%,transparent)] px-4 py-3">
                  <span className="text-[var(--good-text)]">&#10003;</span>
                  <span className="text-sm font-medium text-[var(--good-text)]">Submitted as {c.submittedItemId}</span>
                  <span className="text-xs text-[var(--muted)]">— track it in Demand Tracker</span>
                </div>
              </div>
            ) : c.step !== 'confirmation' && (
              <div className="mx-auto w-full max-w-3xl shrink-0 px-6 pb-5 pt-2">
                {error && (
                  <div className="mb-3 flex items-center justify-between rounded-xl bg-[color-mix(in_srgb,var(--critical)_8%,var(--surface-1))] border border-[color-mix(in_srgb,var(--critical)_25%,transparent)] px-3 py-2 text-sm text-[var(--critical)]">
                    {error}
                    <button className="ml-2 text-xs underline" onClick={() => setError(null)}>dismiss</button>
                  </div>
                )}
                {(view.quickReplies.length > 0 || c.messages.length <= 1) && (
                  <div className="mb-2.5 flex flex-wrap gap-1.5">
                    {(view.quickReplies.length > 0 ? view.quickReplies.map((q) => q.label) : SUGGESTED_PROMPTS).map((label) => (
                      <button key={label} disabled={busy} onClick={() => send(label.replace(/\s*\u2713$/, ''))}
                        className="rounded-full border border-[var(--grid)] bg-[var(--surface-1)] px-3.5 py-1.5 text-[13px] font-medium text-[var(--ink-2)] shadow-sm transition-all hover:border-[var(--brand-ring)] hover:bg-[var(--brand-soft)] hover:text-[var(--brand)] active:translate-y-0 disabled:opacity-40">
                        {label}
                      </button>
                    ))}
                  </div>
                )}
                {attachments.length > 0 && (
                  <div className="mb-2 flex flex-wrap gap-1.5">
                    {attachments.map((name, i) => (
                      <span key={`${name}-${i}`} className="flex items-center gap-1.5 rounded-lg border border-[var(--grid)] bg-[var(--surface-1)] px-2.5 py-1 text-xs text-[var(--ink-2)]">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21.44 11.05l-9.19 9.19a5 5 0 0 1-7.07-7.07l9.19-9.19a3.5 3.5 0 0 1 4.95 4.95l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
                        <span className="max-w-[120px] truncate">{name}</span>
                        <button onClick={() => setAttachments((p) => p.filter((_, j) => j !== i))} className="text-[var(--muted)] hover:text-[var(--critical)]">&#x2715;</button>
                      </span>
                    ))}
                  </div>
                )}
                <input ref={fileInputRef} type="file" multiple className="hidden" onChange={onFilesPicked} />

                {/* Input */}
                <div className="group/composer relative rounded-2xl border border-[var(--grid)] bg-[var(--surface-1)] shadow-sm transition-all duration-200 focus-within:border-[var(--brand)] focus-within:shadow-[0_0_0_3px_var(--brand-soft),0_4px_16px_-6px_var(--brand-ring)]">
                  <Textarea
                    value={input} onValueChange={setInput}
                    onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(input); } }}
                    placeholder="Message Demand Intake Agent…"
                    minRows={1} maxRows={6} variant="flat"
                    classNames={{
                      inputWrapper: 'bg-transparent shadow-none border-0 px-4 pt-3 pb-1 hover:bg-transparent data-[hover=true]:bg-transparent group-data-[focus=true]:bg-transparent',
                      input: 'text-[13.5px] text-[var(--ink)] placeholder:text-[var(--muted)]',
                    }} />
                  <div className="flex items-center justify-between px-3 pb-2.5">
                    <div className="flex items-center gap-0.5">
                      <Tooltip content="Attach files">
                        <button onClick={() => fileInputRef.current?.click()} className="flex h-8 w-8 items-center justify-center rounded-lg text-[var(--muted)] hover:bg-[var(--page)] hover:text-[var(--ink-2)] transition">
                          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21.44 11.05l-9.19 9.19a5 5 0 0 1-7.07-7.07l9.19-9.19a3.5 3.5 0 0 1 4.95 4.95l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
                        </button>
                      </Tooltip>
                      <span className="ml-1 hidden select-none items-center gap-1 text-[11px] text-[var(--muted)] sm:flex">
                        <kbd className="rounded border border-[var(--grid)] bg-[var(--page)] px-1 py-px font-sans text-[10px]">Enter</kbd>
                        to send
                      </span>
                    </div>
                    <div className="flex items-center gap-3.5 pr-1">
                      <button disabled={busy} onClick={handleSaveDraft}
                        className="hidden items-center gap-1 rounded-lg border border-[var(--grid)] bg-[var(--page)] px-2.5 py-1 text-[11.5px] font-medium text-[var(--muted)] transition hover:border-[var(--grid-strong)] hover:text-[var(--ink-2)] disabled:opacity-40">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                        Save draft
                      </button>
                      <button disabled={busy || (!input.trim() && attachments.length === 0)} onClick={() => send(input)}
                        className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-[var(--brand)] to-[var(--brand-deep)] text-white shadow-sm transition-all hover:scale-105 hover:shadow-md active:scale-95 disabled:from-[var(--baseline)] disabled:to-[var(--baseline)] disabled:opacity-60 disabled:hover:scale-100">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </section>

      {/* ── Right panel ─────────────────────────────────────────────── */}
      <aside className="hidden w-[320px] shrink-0 flex-col gap-6 overflow-y-auto border-l border-[var(--grid)] bg-[var(--page)] p-5 xl:flex">
        <ProgressPanel step={c?.step} missing={view?.missingMandatory.length ?? 7} />
        <PromptsPanel items={SUGGESTED_PROMPTS} title="Suggested" busy={busy} step={c?.step} onSend={send} />
        <PromptsPanel items={INSIGHTS} title="Insights" busy={busy} step={c?.step} onSend={send} accent />
      </aside>
    </div>
  );
}

/* ── Right-panel: intake progress ───────────────────────────────────── */
function ProgressPanel({ step, missing }: { step?: ConversationStep; missing: number }) {
  const current = computeStep(step, missing);
  const done = step === 'submitted';
  const total = INTAKE_STEPS.length;
  const completed = done ? total : current - 1;
  const pct = done ? 100 : Math.round(((current - 1) / (total - 1)) * 100);

  return (
    <div className="diq-rise rounded-2xl border border-[var(--grid)] bg-gradient-to-b from-[var(--surface-1)] to-[var(--page)] p-5 shadow-sm">
      <div className="mb-3.5 flex items-center justify-between">
        <span className="text-[11.5px] font-semibold uppercase tracking-wider text-[var(--muted)]">Progress</span>
        <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold tabular-nums ${
          done ? 'bg-[color-mix(in_srgb,var(--good)_16%,transparent)] text-[var(--good-text)]'
               : 'bg-[var(--brand-soft)] text-[var(--brand)]'
        }`}>{done ? 'Complete' : `${completed} / ${total}`}</span>
      </div>

      {/* Gradient bar with travelling sheen while in-flight */}
      <div className="relative mb-5 h-2 w-full overflow-hidden rounded-full bg-[var(--grid)]">
        <div
          className={`relative h-full rounded-full transition-[width] duration-700 ease-out ${!done && pct > 0 && pct < 100 ? 'diq-sheen' : ''}`}
          style={{ width: `${pct}%`, background: done
            ? 'linear-gradient(90deg, var(--good), var(--good-text))'
            : 'linear-gradient(90deg, var(--brand), var(--brand-deep))' }}
        />
      </div>

      <ol className="relative space-y-0.5">
        {/* connector rail behind the markers */}
        <span className="pointer-events-none absolute left-[10px] top-3 bottom-3 w-px bg-[var(--grid)]" />
        {INTAKE_STEPS.map((label, i) => {
          const s = done || i < current - 1 ? 'done' : i === current - 1 ? 'active' : 'todo';
          return (
            <li key={label} className="relative flex items-center gap-3 py-1.5">
              <span className={`relative z-10 grid h-5 w-5 shrink-0 place-items-center rounded-full text-[10px] font-bold transition-all duration-300 ${
                s === 'done' ? 'bg-[var(--good-text)] text-white'
                : s === 'active' ? 'diq-pulse-ring bg-[var(--brand)] text-white ring-2 ring-[var(--brand-ring)]'
                : 'bg-[var(--surface-1)] text-[var(--muted)] ring-1 ring-[var(--grid-strong)]'
              }`}>{s === 'done' ? '✓' : i + 1}</span>
              <span className={`text-[12.5px] leading-snug transition-colors ${
                s === 'active' ? 'font-semibold text-[var(--brand)]' : s === 'done' ? 'text-[var(--ink)]' : 'text-[var(--muted)]'
              }`}>{label}</span>
              {s === 'active' && (
                <span className="ml-auto text-[9px] font-semibold uppercase tracking-wide text-[var(--brand)]">Now</span>
              )}
            </li>
          );
        })}
      </ol>
    </div>
  );
}

function computeStep(step: ConversationStep | undefined, missing: number): number {
  switch (step) {
    case 'confirm_type': return 2;
    case 'questioning': return Math.min(6, 3 + Math.floor((Math.max(0, 7 - missing) / 7) * 4));
    case 'duplicate_decision': return 7;
    case 'confirmation': case 'submitted': return 8;
    default: return 1;
  }
}

/* ── Right-panel: prompts / insights ───────────────────────────────── */
function PromptsPanel({ items, title, busy, step, onSend, accent }: {
  items: string[]; title: string; busy: boolean;
  step?: ConversationStep; onSend: (t: string) => void; accent?: boolean;
}) {
  const disabled = busy || step === 'submitted';
  return (
    <div className="diq-rise rounded-2xl border border-[var(--grid)] bg-gradient-to-b from-[var(--surface-1)] to-[var(--page)] p-5 shadow-sm">
      <div className="mb-3.5 flex items-center gap-2">
        <span className="text-[var(--brand)]">{accent ? <SparkIcon /> : <LightbulbIcon />}</span>
        <span className="text-[11.5px] font-semibold uppercase tracking-wider text-[var(--muted)]">{title}</span>
      </div>
      <div className="space-y-2">
        {items.map((p) => (
          <button key={p} disabled={disabled} onClick={() => onSend(p)}
            className={`diq-prompt group flex w-full items-center gap-3 rounded-xl px-3.5 py-3 text-left text-[13px] leading-snug
              ${accent
                ? 'text-[var(--ink-2)] hover:bg-[var(--brand-soft)] hover:text-[var(--brand)]'
                : 'border border-[var(--grid)] bg-[var(--surface-1)] text-[var(--ink-2)] hover:border-[var(--brand-ring)] hover:bg-[var(--brand-soft)] hover:text-[var(--brand)]'}
              disabled:pointer-events-none disabled:opacity-40`}>
            {accent
              ? <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-[var(--brand)]" />
              : <span className="text-[var(--muted)] transition-colors group-hover:text-[var(--brand)]"><ChatBubbleIcon /></span>}
            <span className="flex-1">{p}</span>
            <span className="diq-chevron shrink-0 text-[var(--brand)]">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

function SparkIcon() {
  return <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l1.6 5.4L19 9l-5.4 1.6L12 16l-1.6-5.4L5 9l5.4-1.6L12 2z"/></svg>;
}
function LightbulbIcon() {
  return <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-4 10.5c.5.5 1 1.3 1 2.5h6c0-1.2.5-2 1-2.5A6 6 0 0 0 12 3z"/></svg>;
}
function ChatBubbleIcon() {
  return <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>;
}

function fmtTime(iso: string): string {
  return new Date(iso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}