import { useState } from 'react';
import type { MockUser } from '../types';

/** Compact avatar + dropdown, lives in the global header so the signed-in
 *  user (and org switch, for the demo) is visible from every view. */
export function UserMenu({ user, users, onSwitchUser }: {
  user: MockUser; users: MockUser[]; onSwitchUser: (id: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const canSwitch = users.length > 1;

  return (
    <div className="relative">
      <button onClick={() => canSwitch && setOpen((o) => !o)}
        className={`flex items-center gap-2 rounded-lg py-1 pl-1 pr-2 transition ${canSwitch ? 'hover:bg-[var(--page)]' : 'cursor-default'}`}>
        <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[var(--brand-soft)] text-[11px] font-bold text-[var(--brand)]">
          {user.name.charAt(0)}
        </span>
        <span className="hidden min-w-0 text-left md:block">
          <span className="block max-w-[140px] truncate text-[12.5px] font-medium leading-tight text-[var(--ink)]">{user.name}</span>
          <span className="block max-w-[140px] truncate text-[10.5px] leading-tight text-[var(--muted)]">{user.orgName}</span>
        </span>
        {canSwitch && (
          <span className="hidden text-[var(--muted)] md:block">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
          </span>
        )}
      </button>

      {open && canSwitch && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-full z-20 mt-1.5 w-56 overflow-hidden rounded-xl border border-[var(--grid)] bg-[var(--elevated)] p-1 shadow-lg">
            <div className="px-2.5 pb-1 pt-1.5 text-[10px] font-semibold uppercase tracking-wider text-[var(--muted)]">Switch account</div>
            {users.map((u) => {
              const sel = u.id === user.id;
              return (
                <button key={u.id} onClick={() => { onSwitchUser(u.id); setOpen(false); }}
                  className={`flex w-full items-center gap-2.5 rounded-lg px-2 py-1.5 text-left transition ${sel ? 'bg-[var(--brand-soft)]' : 'hover:bg-[var(--page)]'}`}>
                  <span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[11px] font-bold ${sel ? 'bg-[var(--brand)] text-white' : 'bg-[var(--brand-soft)] text-[var(--brand)]'}`}>{u.name.charAt(0)}</span>
                  <span className="min-w-0 flex-1">
                    <span className={`block truncate text-[12px] font-medium ${sel ? 'text-[var(--brand)]' : 'text-[var(--ink)]'}`}>{u.name}</span>
                    <span className="block truncate text-[11px] text-[var(--muted)]">{u.orgName}</span>
                  </span>
                  {sel && (
                    <span className="text-[var(--brand)]">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
