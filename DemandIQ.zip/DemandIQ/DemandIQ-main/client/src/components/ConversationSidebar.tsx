import { useEffect, useState } from 'react';
import { Tooltip } from '@nextui-org/react';
import { api } from '../api';
import type { ConversationSummary } from '../types';

export type View = 'new' | 'tracker' | 'log';

/**
 * Left sidebar for the Demand Intake view — pure chat history. Collapsible,
 * with search, and per-row rename/delete on hover. Branding and account
 * switching live in the global header, not here.
 */
export function ConversationSidebar({
  userId, activeConv, onNewChat, onOpenConversation, onDeleteActive, refreshKey,
  collapsed, onToggleCollapse,
}: {
  userId: string; activeConv: string | null;
  onNewChat: () => void; onOpenConversation: (id: string) => void;
  onDeleteActive: () => void; refreshKey: number;
  collapsed: boolean; onToggleCollapse: () => void;
}) {
  const [convs, setConvs] = useState<ConversationSummary[]>([]);
  const [query, setQuery] = useState('');
  const [menuFor, setMenuFor] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draftTitle, setDraftTitle] = useState('');

  useEffect(() => {
    api.listConversations(userId).then(setConvs).catch(() => setConvs([]));
  }, [userId, refreshKey]);

  const filtered = query.trim()
    ? convs.filter((c) => (c.title || 'New demand').toLowerCase().includes(query.trim().toLowerCase()))
    : convs;

  async function commitRename(id: string) {
    const title = draftTitle.trim();
    setEditingId(null);
    if (!title) return;
    setConvs((prev) => prev.map((c) => (c.id === id ? { ...c, title } : c)));
    try { await api.renameConversation(id, title); } catch { /* keep optimistic */ }
  }

  async function remove(id: string) {
    setMenuFor(null);
    setConvs((prev) => prev.filter((c) => c.id !== id));
    try { await api.deleteConversation(id); } catch { /* ignore */ }
    if (id === activeConv) onDeleteActive();
  }

  /* ── Collapsed rail ─────────────────────────────────────────────── */
  if (collapsed) {
    return (
      <nav className="flex w-14 shrink-0 flex-col items-center gap-2 border-r border-[var(--grid)] bg-[var(--surface-1)] py-3">
        <Tooltip content="Open chat history" placement="right">
          <button onClick={onToggleCollapse} className="flex h-9 w-9 items-center justify-center rounded-xl text-[var(--muted)] transition hover:bg-[var(--page)] hover:text-[var(--ink-2)]">
            <PanelIcon open />
          </button>
        </Tooltip>
        <Tooltip content="New demand" placement="right">
          <button onClick={onNewChat} className="flex h-9 w-9 items-center justify-center rounded-xl bg-[var(--brand-soft)] text-[var(--brand)] transition hover:bg-[var(--brand)] hover:text-white">
            <PlusIcon />
          </button>
        </Tooltip>
      </nav>
    );
  }

  /* ── Expanded sidebar ───────────────────────────────────────────── */
  return (
    <aside className="flex w-[260px] shrink-0 flex-col overflow-hidden border-r border-[var(--grid)] bg-[var(--surface-1)]">
      {/* Header row */}
      <div className="flex items-center justify-between px-3.5 pt-3.5 pb-2">
        <span className="text-[11px] font-semibold uppercase tracking-wider text-[var(--muted)]">Chat history</span>
        <Tooltip content="Close" placement="bottom">
          <button onClick={onToggleCollapse} className="flex h-7 w-7 items-center justify-center rounded-lg text-[var(--muted)] transition hover:bg-[var(--page)] hover:text-[var(--ink-2)]">
            <PanelIcon />
          </button>
        </Tooltip>
      </div>

      {/* New demand */}
      <div className="px-3 pb-2">
        <button onClick={onNewChat}
          className="flex w-full items-center justify-center gap-2 rounded-xl border border-[var(--grid)] bg-[var(--page)] px-3 py-2 text-[13px] font-semibold text-[var(--ink)] transition hover:border-[var(--brand-ring)] hover:bg-[var(--brand-soft)] hover:text-[var(--brand)]">
          <PlusIcon /> New demand
        </button>
      </div>

      {/* Search */}
      <div className="px-3 pb-2">
        <div className="flex items-center gap-2 rounded-xl border border-[var(--grid)] bg-[var(--page)] px-2.5 py-1.5 focus-within:border-[var(--brand-ring)]">
          <span className="text-[var(--muted)]"><SearchIcon /></span>
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search chats"
            className="w-full bg-transparent text-[13px] text-[var(--ink)] placeholder:text-[var(--muted)] focus:outline-none" />
          {query && (
            <button onClick={() => setQuery('')} className="text-[var(--muted)] hover:text-[var(--ink-2)]"><XIcon /></button>
          )}
        </div>
      </div>

      <div className="mx-3 my-1.5 h-px bg-[var(--grid)]" />
      <div className="px-4 pb-1 text-[10px] font-semibold uppercase tracking-wider text-[var(--muted)]">
        {query ? `Results (${filtered.length})` : 'Recent'}
      </div>

      {/* Conversation list */}
      <div className="flex-1 overflow-y-auto px-2 pb-3">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center gap-1.5 px-3 pt-8 text-center">
            <span className="text-[var(--baseline)]"><ChatIcon size={24} /></span>
            <p className="text-xs text-[var(--muted)]">{query ? 'No matches' : 'No conversations yet'}</p>
            {!query && <p className="text-[11px] text-[var(--baseline)]">Start a new demand above</p>}
          </div>
        ) : (
          <ul className="space-y-0.5">
            {filtered.map((x) => {
              const active = x.id === activeConv;
              const isDraft = x.status === 'Draft';
              const editing = editingId === x.id;
              return (
                <li key={x.id} className="relative">
                  {editing ? (
                    <input autoFocus value={draftTitle}
                      onChange={(e) => setDraftTitle(e.target.value)}
                      onBlur={() => commitRename(x.id)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') { e.preventDefault(); commitRename(x.id); }
                        if (e.key === 'Escape') setEditingId(null);
                      }}
                      className="w-full rounded-lg border border-[var(--brand-ring)] bg-[var(--page)] px-3 py-2 text-[13px] text-[var(--ink)] focus:outline-none" />
                  ) : (
                    <button onClick={() => onOpenConversation(x.id)}
                      className={`group flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-left transition-all ${
                        active ? 'bg-[var(--brand-soft)] ring-1 ring-[var(--brand-ring)]' : 'hover:bg-[var(--page)]'
                      }`}>
                      <span className={`h-2 w-2 shrink-0 rounded-full transition-colors ${active ? 'bg-[var(--brand)]' : isDraft ? 'bg-[var(--warning)]' : 'bg-[var(--baseline)] group-hover:bg-[var(--brand-ring)]'}`} />
                      <span className="min-w-0 flex-1">
                        <span className="flex items-baseline gap-1.5">
                          <span className={`truncate text-[13px] font-medium ${active ? 'text-[var(--brand)]' : 'text-[var(--ink)]'}`}>
                            {x.title || 'New demand'}
                          </span>
                        </span>
                        <span className="mt-0.5 block">
                          {isDraft ? (
                            <span className="inline-flex items-center rounded-full bg-[color-mix(in_srgb,var(--warning)_16%,transparent)] px-1.5 py-px text-[10px] font-medium text-[var(--warning)]">Draft</span>
                          ) : x.demandType ? (
                            <span className="truncate text-xs capitalize text-[var(--muted)]">{x.demandType.replace(/_/g, ' ')}</span>
                          ) : (
                            <span className="text-xs text-[var(--muted)]">{x.messageCount} messages</span>
                          )}
                        </span>
                      </span>
                      {/* hover kebab */}
                      <span
                        role="button" tabIndex={0}
                        onClick={(e) => { e.stopPropagation(); setMenuFor(menuFor === x.id ? null : x.id); }}
                        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); e.stopPropagation(); setMenuFor(menuFor === x.id ? null : x.id); } }}
                        className="absolute right-2 flex h-8 w-8 items-center justify-center rounded-md text-[var(--muted)] opacity-0 transition hover:text-[var(--ink)] group-hover:opacity-100">
                        <KebabIcon />
                      </span>
                    </button>
                  )}

                  {menuFor === x.id && !editing && (
                    <>
                      <div className="fixed inset-0 z-10" onClick={() => setMenuFor(null)} />
                      <div className="absolute right-2 top-9 z-20 w-36 overflow-hidden rounded-xl border border-[var(--grid)] bg-[var(--elevated)] p-1 shadow-lg">
                        <button onClick={() => { setEditingId(x.id); setDraftTitle(x.title || 'New demand'); setMenuFor(null); }}
                          className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left text-[13px] text-[var(--ink-2)] transition hover:bg-[var(--page)]">
                          <PencilIcon /> Rename
                        </button>
                        <button onClick={() => remove(x.id)}
                          className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left text-[13px] text-[var(--critical)] transition hover:bg-[color-mix(in_srgb,var(--critical)_10%,transparent)]">
                          <TrashIcon /> Delete
                        </button>
                      </div>
                    </>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </aside>
  );
}

function relTime(iso: string): string {
  const d = new Date(iso), now = new Date();
  if (d.toDateString() === now.toDateString())
    return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  const yest = new Date(now); yest.setDate(now.getDate() - 1);
  if (d.toDateString() === yest.toDateString()) return 'Yesterday';
  return d.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

/* ── icons ──────────────────────────────────────────────────────────── */
function PanelIcon({ open = false }: { open?: boolean }) {
  return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="9" y1="3" x2="9" y2="21"/>{open ? <polyline points="11 9 14 12 11 15"/> : <polyline points="14 9 11 12 14 15"/>}</svg>;
}
function PlusIcon() {
  return <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>;
}
function SearchIcon() {
  return <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>;
}
function XIcon() {
  return <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>;
}
function KebabIcon() {
  return <svg width="19" height="19" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="12" cy="19" r="1.8"/></svg>;
}
function PencilIcon() {
  return <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>;
}
function TrashIcon() {
  return <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>;
}
function ChatIcon({ size = 17 }: { size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>;
}
