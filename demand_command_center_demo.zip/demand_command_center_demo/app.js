const h = (tag, attrs = {}, children = []) => {
  const el = document.createElement(tag);
  Object.entries(attrs || {}).forEach(([k, v]) => {
    if (k === 'class') el.className = v;
    else if (k === 'html') el.innerHTML = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else el.setAttribute(k, v);
  });
  (Array.isArray(children) ? children : [children]).forEach(c => {
    if (c === null || c === undefined) return;
    el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  });
  return el;
};

let screen = 'intake';
let selectedDemand = 'DM-10045';
const root = document.getElementById('root');

const demandRows = [
  ['High','DM-10045','AI Contract Review Assistant','NHS Digital','£420,000','91','Yes','Under Review'],
  ['High','DM-10032','Legal Clause Extraction','NHS Digital','£310,000','88','Yes','Submitted'],
  ['Medium','DM-10028','Contract Risk Scoring','NHS Digital','£260,000','76','No','Submitted'],
  ['Medium','DM-10021','Legal Knowledge Search','NHS Digital','£180,000','72','Yes','More Info Needed'],
  ['Low','DM-10018','Policy Comparison Tool','NHS Digital','£95,000','61','No','Draft']
];

function TopBar(){
  return h('div',{class:'topbar'},[
    h('div',{style:'display:flex;align-items:center;height:100%;'},[
      h('div',{class:'brand'},[h('span',{class:'logo-ring'}),h('span',{},'NTT DATA')]),
      h('span',{class:'divider'}),
      h('span',{class:'product'}, screen==='intake'?'Command Center':'Command Center'),
      h('div',{class:'topnav'},[
        h('button',{class:screen==='intake'?'active':'',onclick:()=>{screen='intake';render();}},'Demand Intake Agent'),
        h('button',{class:screen==='heatmap'?'active':'',onclick:()=>{screen='heatmap';render();}},'Demand Priority Heatmap')
      ])
    ]),
    h('div',{class:'top-actions'},[
      h('button',{class:'icon-button'},'?'),
      h('button',{class:'icon-button'},[document.createTextNode('🔔'),h('span',{class:'badge-dot'},'3')]),
      h('div',{class:'profile'},[h('span',{class:'avatar'},'AM'),h('div',{},[h('b',{},'Alex Morgan'),h('small',{},'Portfolio Manager')]),h('span',{},'⌄')])
    ])
  ]);
}

function IntakeSidebar(){
  const convs = [
    ['AI Contract Review Solution','We are looking to implement an AI...','10:24 AM'],
    ['Supplier Risk Assessment Tool','Need a solution for automated...','Yesterday'],
    ['Intelligent Invoice Processing','Automate invoice capturing and...','May 28'],
    ['Data Privacy Compliance','Looking for a solution to help us...','May 27'],
    ['IT Service Management Platform','Upgrade or implement a new ITSM...','May 26']
  ];
  return h('aside',{class:'sidebar'},[
    h('div',{class:'side-title'},[h('span',{},'Demand Intake'),h('span',{},'+')]),
    h('button',{class:'primary-btn'},'+  New Conversation'),
    h('div',{class:'side-section'},[
      h('h4',{},'Recent Conversations'),
      ...convs.map((c,i)=>h('div',{class:'conv '+(i===0?'active':'')},[h('span',{},'▣'),h('div',{},[h('div',{class:'conv-title'},c[0]),h('small',{},c[1])]),h('small',{},c[2])])),
      h('span',{class:'link'},'View all conversations')
    ]),
    h('div',{class:'side-section'},[
      h('h4',{},'Your Drafts   2'),
      h('div',{class:'conv'},[h('span',{},'◰'),h('div',{},[h('div',{class:'conv-title'},'Employee Onboarding Portal'),h('small',{},'Last updated 2 days ago')])]),
      h('div',{class:'conv'},[h('span',{},'◰'),h('div',{},[h('div',{class:'conv-title'},'Spend Analytics Dashboard'),h('small',{},'Last updated 5 days ago')])]),
      h('span',{class:'link'},'View all drafts')
    ]),
    h('div',{class:'side-section'},[h('div',{class:'help-card'},[h('b',{},'ⓘ  Need help?'),h('div',{},'See guidance on how to submit a demand'),h('span',{class:'link'},'View Intake Guide  →')])])
  ]);
}
function IntakeRightRail(){
  const steps=['Business Objective','Need Overview','Business Context','Scope & Requirements','Value & Impact','Constraints & Dependencies','Additional Information','Review & Confirm'];
  const prompts=['What information do you need from me?','What are the common solution approaches for this type of need?','Can you show similar demands submitted by others?','How long does the intake and review process take?','What happens after I submit this demand?'];
  const insights=['Similar demands and outcomes','Estimated effort and timeline','Potential solution areas','Related policies and guidelines'];
  return h('div',{class:'right-rail'},[
    h('div',{class:'panel'},[h('div',{class:'panel-head'},[h('h3',{},'Intake Progress'),h('span',{class:'meta'},'Step 2 of 8')]),h('div',{class:'progressbar'},h('span')), ...steps.map((s,i)=>h('div',{class:'step '+(i===0?'done ':i===1?'active ':'')},[h('span',{class:'num'},i===0?'✓':String(i+1)),h('span',{},s)]))]),
    h('div',{class:'panel'},[h('h3',{},'Suggested prompts'),...prompts.map(p=>h('div',{class:'prompt-card'},[h('span',{},p),h('b',{class:'blue'},'→')]))]),
    h('div',{class:'panel'},[h('h3',{},'Insights you can ask'),...insights.map(i=>h('div',{class:'insight'},[h('span',{class:'insight-icon'},'▣'),h('span',{},i)]))])
  ]);
}
function IntakeMain(){
  return h('main',{class:'main'},[
    h('div',{class:'intake-screen'},[
      h('div',{class:'chat-wrap'},[
        h('div',{class:'page-head'},[h('span',{class:'bot-icon'},'🤖'),h('div',{},[h('h1',{},['Demand Intake Agent ',h('span',{class:'pill'},'Beta')]),h('p',{},'I\'ll help you capture your business need and create a demand for the right solution.')])]),
        h('div',{class:'messages'},[
          h('div',{class:'row'},[h('span',{class:'bot-icon'},'🤖'),h('div',{class:'bubble',html:'<b>Hi Alex! I\'m your Demand Intake Agent.</b><br><br>I\'ll guide you through a few questions to understand your need and create a comprehensive demand.<br><br>What would you like to achieve?<div class="time">10:24 AM</div>'})]),
          h('div',{class:'row user'},[h('div',{class:'bubble user',html:'We are looking to implement an AI solution to review and extract key clauses from legal contracts.<div class="time">10:24 AM ✓✓</div>'})]),
          h('div',{class:'row'},[h('span',{class:'bot-icon'},'🤖'),h('div',{class:'bubble',html:'Great! I\'ve started capturing your need. I\'ll ask a few questions to get more details.<br>You can answer one by one.<h3>1. What is the primary business objective or outcome you want to achieve?</h3><b>Examples:</b><ul><li>Reduce manual effort and processing time</li><li>Improve accuracy and consistency</li><li>Enhance compliance and risk management</li><li>Improve user experience</li><li>Other (please specify)</li></ul><div class="time">10:24 AM</div>'})])
        ]),
        h('div',{class:'quick-options'},['Reduce manual effort and processing time','Improve accuracy and consistency','Enhance compliance and risk management','Improve user experience','Other (please specify)'].map(t=>h('button',{class:'option'},t))),
        h('div',{class:'composer'},[h('span',{},'📎'),h('input',{placeholder:'Type your answer or ask a follow-up question...'}),h('span',{},'🎙'),h('button',{class:'send'},'▷')]),
        h('div',{class:'fineprint'},'AI-generated content may be incorrect. Please review before submitting.')
      ]),
      IntakeRightRail()
    ])
  ]);
}
function HeatFilterPanel(){
  const groups=[['Customer',['Customer Account','Account Tier','Industry / Sector','Account Owner']],['Geography',['Region','Country']],['Domain / Solution',['Domain','Solution Area']],['Opportunity',['Opportunity Type','Priority','Quick Win']],['Value & Scoring',['Est. Annual Value','Priority Score']],['Status',['Demand Status']]];
  return h('aside',{class:'filter-panel'},[
    h('div',{class:'filter-head'},[h('h3',{},'Filters'),h('button',{class:'clear'},'Clear All')]),
    h('div',{class:'field'},[h('label',{},'Date Range'),h('input',{value:'01 Apr 2024 - 30 Jun 2024',readonly:'true'})]),
    ...groups.map(g=>h('div',{class:'filter-group'},[h('h4',{},g[0]),...g[1].map(f=>h('div',{class:'field'},[h('label',{},f),h('select',{},[h('option',{},'All')])]))])),
    h('button',{class:'apply'},'Apply Filters'),h('button',{class:'save'},'Save View')
  ]);
}
function HeatKpis(){
  const k=[['Total Demands','387','↑ 18% vs prior period'],['Est. Annual Value','£98.7M','↑ 22% vs prior period'],['Avg. Priority Score','74','↑ 5 vs prior period'],['High Priority Demands','142 (37%)','↑ 12% vs prior period'],['Quick Wins','96 (25%)','↑ 8% vs prior period'],['Strategic Bets','41 (11%)','↑ 4% vs prior period']];
  return h('div',{class:'kpis'},k.map(x=>h('div',{class:'kpi'},[h('small',{},x[0]),h('b',{},x[1]),h('span',{class:'up'},x[2])])));
}
function HeatmapTable(){
  const rows=[['⌄  Europe',['28','£6.2M','h4'],['16','£2.1M','h2'],['34','£7.8M','h4'],['22','£4.3M','h3'],['18','£3.2M','h2'],['15','£2.6M','h2'],['27','£5.1M','h4'],['160','£31.3M','total']],['   United Kingdom',['12','£2.8M','h2'],['6','£0.9M','h1'],['14','£3.1M','h3'],['9','£1.7M','h2'],['8','£1.2M','h1'],['5','£0.8M','h1'],['11','£2.1M','h2'],['65','£11.6M','total']],['   Germany',['9','£1.9M','h2'],['5','£0.7M','h1'],['10','£2.3M','h2'],['6','£1.1M','h1'],['5','£0.9M','h1'],['5','£0.7M','h1'],['8','£1.6M','h2'],['48','£7.2M','total']],['   France',['7','£1.5M','h1'],['5','£0.5M','h1'],['10','£2.4M','h2'],['7','£1.5M','h1'],['5','£1.1M','h1'],['5','£1.1M','h1'],['8','£1.4M','h2'],['47','£8.0M','total']],['›  Asia Pacific',['22','£5.0M','h3'],['14','£1.7M','h2'],['26','£6.2M','h4'],['18','£3.0M','h3'],['16','£2.8M','h2'],['14','£2.4M','h2'],['20','£4.0M','h3'],['130','£25.1M','total']],['›  Americas',['20','£4.8M','h3'],['12','£1.6M','h2'],['24','£6.0M','h4'],['16','£2.8M','h2'],['14','£2.3M','h2'],['12','£2.1M','h2'],['19','£3.6M','h3'],['117','£23.2M','total']],['Grand Total',['70','£16.0M','total'],['42','£5.4M','total'],['84','£20.0M','total'],['56','£10.1M','total'],['48','£8.3M','total'],['41','£7.1M','total'],['66','£12.7M','total'],['387','£98.7M','total']]];
  const headers=['Region / Country','Finance','HR','Operations','Legal','Customer Experience','Supply Chain','Technology','Total'];
  return h('table',{class:'heat-table'},[h('thead',{},h('tr',{},headers.map(x=>h('th',{},x)))),h('tbody',{},rows.map(r=>h('tr',{},[h('td',{},r[0]),...r.slice(1).map(c=>h('td',{class:'heat-cell '+c[2],onclick:()=>{}},[c[0],h('span',{},`(${c[1]})`)]))])))])
}
function DemandResults(){
  return h('div',{class:'section-card'},[
    h('div',{class:'result-head'},[h('div',{},[h('h2',{},['Demands in Legal / United Kingdom / High Priority ',h('span',{class:'blue'},'(9)')]),h('span',{class:'tag'},'Est. Annual Value: £1.7M')]),h('input',{class:'search',placeholder:'Search demands...'})]),
    h('table',{class:'demand-table'},[h('thead',{},h('tr',{},['Priority','Demand ID','Demand Title','Customer Account','Est. Annual Value','Priority Score','Quick Win','Status'].map(x=>h('th',{},x)))),h('tbody',{},demandRows.map(r=>h('tr',{class:selectedDemand===r[1]?'active':'',onclick:()=>{selectedDemand=r[1];render();}},[
      h('td',{},h('span',{class:'priority '+r[0].toLowerCase()},r[0])),h('td',{class:'blue'},r[1]),h('td',{},r[2]),h('td',{},r[3]),h('td',{},r[4]),h('td',{},r[5]),h('td',{},h('span',{class:r[6]==='Yes'?'green':'red'},r[6])),h('td',{},h('span',{class:'status'},r[7]))
    ])))]),
    h('p',{class:'hint'},'Showing 1 to 5 of 9 demands')
  ]);
}
function DemandDetail(){
  return h('aside',{class:'detail'},[
    h('div',{class:'detail-top'},[h('h3',{},'Demand Details'),h('button',{class:'icon-button'},'×')]),
    h('div',{class:'meta'},'DM-10045   '),h('span',{class:'priority high'},'High Priority'),
    h('h2',{},'AI Contract Review Assistant'),
    h('div',{class:'meta'},'NHS Digital  |  Legal  |  United Kingdom'),
    h('div',{style:'margin:10px 0'},[h('span',{class:'status'},'Under Review'),document.createTextNode('  '),h('span',{class:'status'},'Proactive Proposal')]),
    h('div',{class:'detail-kpis'},[
      ['Priority Score','91 /100','blue'],['Strategic Impact','High','green'],['Business Value','High','green'],['Est. Annual Value','£420,000',''],['ROI Potential','2.8x',''],['Ease of Implementation','Medium','orange'],['Quick Win Potential','Yes','green'],['Confidence Level','High','green'],['Strategic Fit','High','green']
    ].map(x=>h('div',{class:'mini'},[h('small',{},x[0]),h('b',{class:x[2]},x[1])]))),
    h('h4',{},'Executive Summary'),h('p',{},'Implement an AI-powered contract review solution to reduce manual review time, improve accuracy, and standardize clause extraction across legal documents.'),
    h('h4',{},'Solution Areas'),h('p',{},'Generative AI · Document Intelligence · NLP · Workflow Automation'),
    h('h4',{},'Recommended Solution Approach (High Level)'),h('p',{},'Start with a focused MVP to ingest contracts, extract key clauses, and provide AI-assisted review with a human-in-the-loop workflow. Expand to full contract lifecycle management based on pilot outcomes.'),
    h('h4',{},'Recommended Skills / Resource Roles (Advisory)'),
    h('table',{class:'role-table'},[h('thead',{},h('tr',{},['Role','Key Skills','FTE','Phase'].map(x=>h('th',{},x)))),h('tbody',{},[
      ['Solution Architect','Azure AI, Solution Design','1','Discovery'],['Data Engineer','Azure, Data Pipelines','1-2','Build'],['ML Engineer','NLP, LLM, Prompt Eng.','1-2','Build'],['Software Developer','.NET, React, APIs','2-3','Build'],['UX / UI Designer','Workflow UX','1','Build'],['QA Engineer','Test Automation','1','Build']
    ].map(r=>h('tr',{},r.map(c=>h('td',{},c))))) ]),
    h('h4',{},'Additional Information'),h('p',{},'Submitted by Sarah Thompson · Submitted on 12 Jun 2024 · Account Owner James Walker · Tags: AI, Contracts, Automation'),
    h('button',{class:'detail-button'},'View Full Demand Record  ↗')
  ]);
}
function HeatmapMain(){
  return h('main',{class:'main'},h('div',{class:'heatmap-screen'},[HeatFilterPanel(),h('div',{class:'heat-main'},[
    HeatKpis(),
    h('div',{class:'section-card'},[h('div',{class:'section-title'},[h('h2',{},'Portfolio Heatmap (Count of Demands)  ⓘ'),h('div',{class:'controls'},[h('span',{},'View by:'),h('select',{},h('option',{},'Domain')),h('span',{},'Color by:'),h('select',{},h('option',{},'Avg. Priority Score')),h('span',{class:'legend'},['Low ',h('span',{class:'grad'}),' High']),h('label',{},[h('input',{type:'checkbox',checked:'true'}),' Show values'])])]),HeatmapTable(),h('p',{class:'hint'},'Click on any cell to view demands. Drill down by region, country, domain, or account using filters.')]),
    DemandResults()
  ]),DemandDetail()]))
}
function render(){
  root.innerHTML='';
  const app=h('div',{class:'app'},[TopBar(),h('div',{class:'workspace'},screen==='intake'?[IntakeSidebar(),IntakeMain()]:[HeatmapMain()])]);
  root.appendChild(app);
}
render();
