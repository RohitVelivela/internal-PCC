# Demand Command Center Demo

This is a self-contained HTML/CSS/JS demo for two Command Center screens:

1. Demand Intake Agent - GPT-style guided intake interface
2. Demand Priority Heatmap - portfolio heatmap, demand list, and right-side demand detail panel

## Run locally

Open `index.html` directly, or run:

```bash
python -m http.server 8000
```

Then open:

```text
http://localhost:8000
```

No external libraries, CDN, npm install, or build step is required. The JavaScript is componentized and intentionally dependency-free so it works in locked-down environments.
